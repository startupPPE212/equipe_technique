import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialize Gemini clients to avoid crashing if API key is not present initially
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      // Return a mock client structure or throw a clear error that we catch
      console.warn("WARNING: GEMINI_API_KEY is not defined in environment variables. Running in mock AI mode.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key || "MOCK_KEY",
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// In-Memory Database representing a comprehensive real-world startup dataset
// Users, Products, Job Offers, Orders. Sync with memory but keep structure clean.
let users = [
  // Clients
  { id: "c1", email: "client1@email.com", name: "Jean Dupont", profileType: "client", description: "Je cherche des produits frais et locaux.", address: "Paris, France", phone: "+33 6 12345678" },
  { id: "c2", email: "client2@email.com", name: "Marie Koné", profileType: "client", description: "Je cherche de l'artisanat et des opportunités d'emploi.", address: "Abidjan, Côte d'Ivoire", phone: "+225 07 483920" },

  // Enterprises
  { id: "e1", email: "super@prestige.com", name: "Prestige Market", profileType: "entreprise", enterpriseType: "supermarche", description: "Supermarché haut de gamme offrant des produits locaux et importés.", address: "Abidjan, Zone 4", phone: "+225 21 001122" },
  { id: "e2", email: "marie@resto.com", name: "Chez Marie l'Africaine", profileType: "entreprise", enterpriseType: "restaurant", description: "Restaurant traditionnel africain et européen de qualité.", address: "Dakar, Plateau", phone: "+221 33 821 2233" },
  { id: "e3", email: "hotel@royal.com", name: "Hôtel Royal Résidence", profileType: "entreprise", enterpriseType: "hotel", description: "Hôtel 4 étoiles avec service navette, piscine et restaurant.", address: "Bamako, Mali", phone: "+223 20 221133" },
  { id: "e4", email: "doc@pro.com", name: "Pro-Doc Services", profileType: "entreprise", enterpriseType: "secretariat", description: "Services administratifs, reliure thermique, traduction et photocopie.", address: "Lomé, Togo", phone: "+228 22 214578" },
  { id: "e5", email: "marche@panier.com", name: "Le Panier Frais", profileType: "entreprise", enterpriseType: "marche", description: "Marché couvert de quartier vendant des fruits et légumes bio.", address: "Yaoundé, Cameroun", phone: "+237 222 301234" },

  // Suppliers
  { id: "s1", email: "ferme@bio.com", name: "Gérard l'Agriculteur", profileType: "fournisseur", supplierType: "agriculteur", description: "Producteur de fruits, tubercules et légumes de saison biologiques.", address: "Sud-Sassandra, Côte d'Ivoire", phone: "+225 01 020304" },
  { id: "s2", email: "bois@artisan.com", name: "Koffi l'Artisan du Bois", profileType: "fournisseur", supplierType: "artisan", description: "Sculpteur traditionnel, création d'ustensiles de cuisine et mobilier.", address: "Abengourou, Côte d'Ivoire", phone: "+225 05 080910" },
  { id: "s3", email: "elevage@savane.com", name: "La Ferme des Savanes", profileType: "fournisseur", supplierType: "eleveur", description: "Élevage responsable de volailles de brousse, chèvres et lapins.", address: "Bouaké, Côte d'Ivoire", phone: "+225 07 090909" }
];

let products = [
  // Products from Enterprises (sold to Clients)
  { id: "p1", sellerId: "e1", sellerName: "Prestige Market", sellerType: "entreprise", title: "Lait entier premium", description: "Lait entier pasteurisé de qualité supérieure.", price: 1200, category: "Alimentation", stock: 150, unit: "brique 1L" },
  { id: "p2", sellerId: "e1", sellerName: "Prestige Market", sellerType: "entreprise", title: "Lessive liquide Éco+", description: "Lessive écologique parfum lavande très efficace.", price: 4500, category: "Entretien", stock: 40, unit: "bidon 3L" },
  { id: "p3", sellerId: "e2", sellerName: "Chez Marie l'Africaine", sellerType: "entreprise", title: "Plat de Tiep bou dienn", description: "Riz au poisson traditionnel sénégalais avec légumes frais marinés.", price: 3500, category: "Repas", stock: 100, unit: "portion" },
  { id: "p4", sellerId: "e2", sellerName: "Chez Marie l'Africaine", sellerType: "entreprise", title: "Plat d'Attiéké au poisson braisé", description: "Semoule de manioc accompagnée d'un poisson braisé et de sauce pimentée.", price: 4000, category: "Repas", stock: 80, unit: "portion" },
  { id: "p5", sellerId: "e3", sellerName: "Hôtel Royal Résidence", sellerType: "entreprise", title: "Chambre Deluxe Single", description: "Chambre climatisée avec lit King size, Wi-Fi ultra-rapide et petit-déjeuner inclus.", price: 65000, category: "Hébergement", stock: 15, unit: "nuitée" },
  { id: "p6", sellerId: "e4", sellerName: "Pro-Doc Services", sellerType: "entreprise", title: "Impression document A4", description: "Saisie et impression noir et blanc ou couleur haute définition.", price: 150, category: "Bureautique", stock: 1000, unit: "page" },
  { id: "p7", sellerId: "e5", sellerName: "Le Panier Frais", sellerType: "entreprise", title: "Tomates fraîches locales", description: "Tomates charnues mûries au soleil sans engrais chimiques.", price: 800, category: "Légumes", stock: 200, unit: "kg" },

  // Products from Suppliers (sold to Enterprises)
  { id: "p8", sellerId: "s1", sellerName: "Gérard l'Agriculteur", sellerType: "fournisseur", title: "Sac de Manioc Frais", description: "Racines de manioc fraîchement déterrées, prêtes pour faire de l'attiéké ou du foufou.", price: 15000, category: "Tubercule", stock: 15, unit: "sac 50kg" },
  { id: "p9", sellerId: "s1", sellerName: "Gérard l'Agriculteur", sellerType: "fournisseur", title: "Pommes de terre locales", description: "Pommes de terre locales de qualité supérieure idéales pour la restauration.", price: 12000, category: "Légume", stock: 30, unit: "sac 25kg" },
  { id: "p10", sellerId: "s2", sellerName: "Koffi l'Artisan du Bois", sellerType: "fournisseur", title: "Mortier traditionnel en bois", description: "Mortier sculpté à la main en bois d'Iroko ultra durable, avec pilon.", price: 18000, category: "Artisanat", stock: 8, unit: "ensemble" },
  { id: "p11", sellerId: "s3", sellerName: "La Ferme des Savanes", sellerType: "fournisseur", title: "Poulet de brousse frais", description: "Poulets élevés en plein air, fermes et savoureux, pour les restaurants de cuisine traditionnelle.", price: 3500, category: "Volaille", stock: 50, unit: "unité" }
];

let jobOffers = [
  { id: "j1", companyId: "e2", companyName: "Chez Marie l'Africaine", companyType: "restaurant", title: "Chef Cuisinier Adjoint", description: "Nous recherchons un cuisinier passionné par la gastronomie locale pour la préparation des plats du jour et la créativité du menu.", salary: "250,000 FCFA / mois", location: "Dakar Plateau", requirements: ["Expérience de 3 ans", "Maîtrise des classiques de la cuisine africaine", "Rigoureux"], createdAt: "2026-05-25" },
  { id: "j2", companyId: "e1", companyName: "Prestige Market", companyType: "supermarche", title: "Hôte de Caisse (H/F)", description: "Poste à pourvoir immédiatement pour l'accueil de notre clientèle haut de gamme et l'encaissement.", salary: "180,000 FCFA / mois", location: "Abidjan, Zone 4", requirements: ["Souriant", "Bonne élocution", "Honnête et ponctuel"], createdAt: "2026-05-28" },
  { id: "j3", companyId: "e3", companyName: "Hôtel Royal Résidence", companyType: "hotel", title: "Réceptionniste de nuit", description: "Assurer la réception physique et téléphonique de l'hôtel durant la nuit, veiller à la sécurité et au confort des hôtes.", salary: "300,000 FCFA / mois", location: "Bamako, Mali", requirements: ["Bilingue Français/Anglais", "Maîtrise des logiciels hôteliers", "Excellente présentation"], createdAt: "2026-05-29" }
];

let orders = [
  { id: "o1", buyerId: "c1", buyerName: "Jean Dupont", sellerId: "e1", sellerName: "Prestige Market", productId: "p1", productTitle: "Lait entier premium", price: 1200, quantity: 5, status: "shipped", createdAt: "2026-05-27T10:00:00Z" },
  { id: "o2", buyerId: "e2", buyerName: "Chez Marie l'Africaine", sellerId: "s1", sellerName: "Gérard l'Agriculteur", productId: "p8", productTitle: "Sac de Manioc Frais", price: 15000, quantity: 2, status: "accepted", createdAt: "2026-05-28T14:30:00Z" }
];

let ventes = [
  {
    id: "v1",
    entreprise_id: "e1",
    age: "18-25",
    sexe: "Femme",
    total: 2400,
    date_vente: "2026-05-28T09:12:00Z",
    items: [
      { id: "vi1", rayon: "Alimentation", produit: "Lait entier premium", quantite: 2, prix_unitaire: 1200, total: 2400 }
    ]
  },
  {
    id: "v2",
    entreprise_id: "e1",
    age: "26-39",
    sexe: "Homme",
    total: 10200,
    date_vente: "2026-05-28T11:45:00Z",
    items: [
      { id: "vi2", rayon: "Alimentation", produit: "Lait entier premium", quantite: 3, prix_unitaire: 1200, total: 3600 },
      { id: "vi3", rayon: "Entretien", produit: "Lessive liquide Éco+", quantite: 1, prix_unitaire: 4500, total: 4500 },
      { id: "vi4", rayon: "Légumes", produit: "Tomates fraîches locales", quantite: 2, prix_unitaire: 800, total: 1600 }
    ]
  },
  {
    id: "v3",
    entreprise_id: "e1",
    age: "40-55",
    sexe: "Femme",
    total: 8000,
    date_vente: "2026-05-29T08:30:00Z",
    items: [
      { id: "vi5", rayon: "Légumes", produit: "Tomates fraîches locales", quantite: 10, prix_unitaire: 800, total: 8000 }
    ]
  },
  {
    id: "v4",
    entreprise_id: "e1",
    age: "26-39",
    sexe: "Femme",
    total: 12200,
    date_vente: "2026-05-29T10:15:00Z",
    items: [
      { id: "vi6", rayon: "Alimentation", produit: "Lait entier premium", quantite: 1, prix_unitaire: 1200, total: 1200 },
      { id: "vi7", rayon: "Entretien", produit: "Lessive liquide Éco+", quantite: 2, prix_unitaire: 4500, total: 9000 },
      { id: "vi8", rayon: "Légumes", produit: "Tomates fraîches locales", quantite: 2, prix_unitaire: 800, total: 1600 }
    ]
  },
  {
    id: "v5",
    entreprise_id: "e2",
    age: "18-25",
    sexe: "Homme",
    total: 7500,
    date_vente: "2026-05-28T13:20:00Z",
    items: [
      { id: "vi9", rayon: "Repas", produit: "Plat de Tiep bou dienn", quantite: 1, prix_unitaire: 3500, total: 3500 },
      { id: "vi10", rayon: "Repas", produit: "Plat d'Attiéké au poisson braisé", quantite: 1, prix_unitaire: 4000, total: 4000 }
    ]
  },
  {
    id: "v6",
    entreprise_id: "e2",
    age: "26-39",
    sexe: "Femme",
    total: 8000,
    date_vente: "2026-05-28T19:40:00Z",
    items: [
      { id: "vi11", rayon: "Repas", produit: "Plat d'Attiéké au poisson braisé", quantite: 2, prix_unitaire: 4000, total: 8000 }
    ]
  },
  {
    id: "v7",
    entreprise_id: "e2",
    age: "55+",
    sexe: "Homme",
    total: 3500,
    date_vente: "2026-05-29T12:00:00Z",
    items: [
      { id: "vi12", rayon: "Repas", produit: "Plat de Tiep bou dienn", quantite: 1, prix_unitaire: 3500, total: 3500 }
    ]
  }
];

// Helper calculations for Profile Match Ratings
const ageMapping: Record<string, number> = {
  "12-18": 15,
  "18-25": 22,
  "19-25": 22,
  "26-39": 32,
  "40-55": 47,
  "55+": 60
};

function getAgeValue(age: string): number {
  return ageMapping[age] || 32;
}

// Real-world demographic profile classifier recommendation logic
function recommendProducts(localVentes: any[], targetAge: string, targetSexe: string) {
  const targetAgeVal = getAgeValue(targetAge);
  const scores: Record<string, number> = {};

  localVentes.forEach(v => {
    const vAgeVal = getAgeValue(v.age);
    const ageDiff = Math.abs(targetAgeVal - vAgeVal);
    const sexeMatch = (v.sexe === targetSexe) ? 1.0 : 0.0;
    const similarity = (1 / (1 + ageDiff)) + sexeMatch;

    v.items.forEach((item: any) => {
      scores[item.produit] = (scores[item.produit] || 0) + similarity * item.quantite;
    });
  });

  return Object.entries(scores)
    .map(([produit, score]) => ({ produit, score }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);
}

// Basket affinity recommendations
function recommendAdvanced(localVentes: any[], currentBasketProducts: string[], targetAge: string, targetSexe: string) {
  if (!currentBasketProducts || currentBasketProducts.length === 0) return [];
  const targetAgeVal = getAgeValue(targetAge);
  const scores: Record<string, number> = {};

  localVentes.forEach(v => {
    // Check if this sale shares any items with the current cart
    const pastProductNames = v.items.map((item: any) => item.produit);
    const sharesItem = pastProductNames.some((pName: string) => currentBasketProducts.includes(pName));

    if (sharesItem) {
      const vAgeVal = getAgeValue(v.age);
      const ageDiff = Math.abs(targetAgeVal - vAgeVal);
      const sexeMatch = (v.sexe === targetSexe) ? 1.0 : 0.0;
      const profilScore = (1 / (1 + ageDiff)) + sexeMatch;

      v.items.forEach((item: any) => {
        if (!currentBasketProducts.includes(item.produit)) {
          scores[item.produit] = (scores[item.produit] || 0) + profilScore * item.quantite;
        }
      });
    }
  });

  return Object.entries(scores)
    .map(([produit, score]) => ({ produit, score }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);
}

// Predict department for current consumer demography
function computeRayonPrediction(localVentes: any[], targetAge: string, targetSexe: string) {
  const ageVal = getAgeValue(targetAge);
  const sexeVal = targetSexe === "Homme" ? 1 : 0;
  const scoresPerRayon: Record<string, number> = {};

  localVentes.forEach(v => {
    const vAgeVal = getAgeValue(v.age);
    const vSexeVal = v.sexe === "Homme" ? 1 : 0;
    const ageDiff = Math.abs(ageVal - vAgeVal);
    const sexeMatch = (vSexeVal === sexeVal) ? 1 : 0;
    const similarity = (1 / (1 + ageDiff)) + sexeMatch;

    v.items.forEach((item: any) => {
      scoresPerRayon[item.rayon] = (scoresPerRayon[item.rayon] || 0) + similarity * item.quantite;
    });
  });

  const totalScore = Object.values(scoresPerRayon).reduce((sum, val) => sum + val, 0);

  if (totalScore === 0 || Object.keys(scoresPerRayon).length === 0) {
    return {
      bestRayon: "Divers",
      bestScore: 1.0,
      level: "DONNÉES INSUFFISANTES ⚠️" as const,
      probabilities: [{ rayon: "Divers", proba: 1.0 }]
    };
  }

  const sortedList = Object.entries(scoresPerRayon)
    .map(([rayon, score]) => ({
      rayon,
      proba: Number((score / totalScore).toFixed(4))
    }))
    .sort((a, b) => b.proba - a.proba);

  const bestRayon = sortedList[0].rayon;
  const bestScore = sortedList[0].proba;
  let level: 'TRÈS FIABLE 🔥' | 'MOYENNEMENT FIABLE ⚠️' | 'DONNÉES INSUFFISANTES ⚠️' = 'MOYENNEMENT FIABLE ⚠️';
  if (localVentes.length < 3) {
    level = 'DONNÉES INSUFFISANTES ⚠️';
  } else if (bestScore > 0.6) {
    level = 'TRÈS FIABLE 🔥';
  }

  return {
    bestRayon,
    bestScore,
    level,
    probabilities: sortedList.slice(0, 4)
  };
}

// --- API Endpoints ---

// Get complete database snapshot
app.get("/api/state", (req, res) => {
  res.json({
    users,
    products,
    jobOffers,
    orders,
    ventes
  });
});

// Submit a direct walk-in / cashier sale
app.post("/api/ventes", (req, res) => {
  const { entreprise_id, age, sexe, items } = req.body;
  
  if (!entreprise_id || !age || !sexe || !items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "Paramètres manquants ou invalides." });
  }

  // Check stocks first to avoid illegal actions (vente-impossible scenario)
  for (const requestedItem of items) {
    const product = products.find(p => p.sellerId === entreprise_id && p.title.toLowerCase() === requestedItem.produit.toLowerCase());
    
    if (!product) {
      return res.status(400).json({ 
        error: "vente_impossible", 
        message: `Produit "${requestedItem.produit}" non répertorié dans vos étalages.`,
        produit: requestedItem.produit,
        demande: requestedItem.quantite,
        dispo: 0 
      });
    }

    if (product.stock < requestedItem.quantite) {
      return res.status(400).json({
        error: "vente_impossible",
        message: `Quantité insuffisante pour "${product.title}".`,
        produit: product.title,
        demande: requestedItem.quantite,
        dispo: product.stock
      });
    }
  }

  // Decrement physical stock
  let totalCalculated = 0;
  const processedItems = items.map((requestedItem: any) => {
    const product = products.find(p => p.sellerId === entreprise_id && p.title.toLowerCase() === requestedItem.produit.toLowerCase())!;
    product.stock -= requestedItem.quantite;
    
    const itemTotal = product.price * requestedItem.quantite;
    totalCalculated += itemTotal;

    return {
      id: "vi_" + Math.random().toString(36).substring(2, 9),
      rayon: product.category,
      produit: product.title,
      quantite: requestedItem.quantite,
      prix_unitaire: product.price,
      total: itemTotal
    };
  });

  const newVente = {
    id: "vente_" + Math.random().toString(36).substring(2, 9),
    entreprise_id,
    age,
    sexe,
    total: totalCalculated,
    date_vente: new Date().toISOString(),
    items: processedItems
  };

  ventes.unshift(newVente);
  res.status(201).json({ success: true, vente: newVente });
});

// AI Predictive Recommender Model Endpoint
app.post("/api/recommend", (req, res) => {
  const { entreprise_id, age, sexe, panier } = req.body;
  if (!entreprise_id || !age || !sexe) {
    return res.status(400).json({ error: "entreprise_id, age, et sexe sont requis." });
  }

  const localVentes = ventes.filter(v => v.entreprise_id === entreprise_id);
  const currentBasketProducts = Array.isArray(panier) ? panier : [];

  const staticRecommendations = recommendProducts(localVentes, age, sexe);
  const advancedRecommendations = recommendAdvanced(localVentes, currentBasketProducts, age, sexe);
  const predictionResult = computeRayonPrediction(localVentes, age, sexe);

  res.json({
    success: true,
    staticRecommendations,
    advancedRecommendations,
    predictionResult
  });
});

// Create/Register account
app.post("/api/register", (req, res) => {
  const { name, email, profileType, enterpriseType, supplierType, description, address, phone } = req.body;
  if (!name || !email || !profileType) {
    return res.status(400).json({ error: "Champs obligatoires manquants." });
  }

  // Check if exists
  const existing = users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return res.status(400).json({ error: "Un compte avec cette adresse email existe déjà." });
  }

  const newUser = {
    id: "user_" + Math.random().toString(36).substring(2, 9),
    name,
    email,
    profileType,
    enterpriseType: profileType === 'entreprise' ? enterpriseType : undefined,
    supplierType: profileType === 'fournisseur' ? supplierType : undefined,
    description: description || "",
    address: address || "",
    phone: phone || "",
    avatarUrl: `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(name)}`
  };

  users.push(newUser);
  res.status(201).json({ success: true, user: newUser });
});

// Login simulé
app.post("/api/login", (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: "L'adresse email est requise." });
  }

  const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (!user) {
    return res.status(404).json({ error: "Utilisateur non trouvé. Veuillez vous inscrire d'abord !" });
  }

  res.json({ success: true, user });
});

// Post a product
app.post("/api/products", (req, res) => {
  const { sellerId, title, description, price, category, stock, unit } = req.body;
  
  const user = users.find(u => u.id === sellerId);
  if (!user) {
    return res.status(404).json({ error: "Vendeur non trouvé." });
  }

  const newProduct = {
    id: "product_" + Math.random().toString(36).substring(2, 9),
    sellerId,
    sellerName: user.name,
    sellerType: user.profileType, // entreprise or fournisseur
    title,
    description,
    price: Number(price),
    category,
    stock: Number(stock),
    unit
  };

  products.unshift(newProduct);
  res.status(201).json({ success: true, product: newProduct });
});

// Delete a product
app.delete("/api/products/:id", (req, res) => {
  const { id } = req.params;
  const index = products.findIndex(p => p.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Produit introuvable." });
  }
  products.splice(index, 1);
  res.json({ success: true });
});

// Offer a job (only Entreprise)
app.post("/api/jobs", (req, res) => {
  const { companyId, title, description, salary, location, requirements } = req.body;
  
  const user = users.find(u => u.id === companyId);
  if (!user || user.profileType !== 'entreprise') {
    return res.status(403).json({ error: "Seules les entreprises peuvent publier des offres d'emploi." });
  }

  const newJob = {
    id: "job_" + Math.random().toString(36).substring(2, 9),
    companyId,
    companyName: user.name,
    companyType: user.enterpriseType || "autre",
    title,
    description,
    salary,
    location,
    requirements: requirements || [],
    createdAt: new Date().toISOString().split('T')[0]
  };

  jobOffers.unshift(newJob);
  res.status(201).json({ success: true, job: newJob });
});

// Place an order (Client buying from Enterprise, or Enterprise buying from Supplier)
app.post("/api/orders", (req, res) => {
  const { buyerId, productId, quantity } = req.body;

  const buyer = users.find(u => u.id === buyerId);
  const product = products.find(p => p.id === productId);

  if (!buyer) return res.status(404).json({ error: "Acheteur non trouvé." });
  if (!product) return res.status(404).json({ error: "Produit non trouvé." });
  if (product.stock < quantity) {
    return res.status(400).json({ error: "Stock insuffisant pour ce produit." });
  }

  // Deduct stock
  product.stock -= quantity;

  const newOrder = {
    id: "order_" + Math.random().toString(36).substring(2, 9),
    buyerId,
    buyerName: buyer.name,
    sellerId: product.sellerId,
    sellerName: product.sellerName,
    productId,
    productTitle: product.title,
    price: product.price,
    quantity,
    status: "pending" as const,
    createdAt: new Date().toISOString()
  };

  orders.unshift(newOrder);
  res.status(201).json({ success: true, order: newOrder });
});

// Handle order status updates
app.patch("/api/orders/:id", (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  const order = orders.find(o => o.id === id);
  if (!order) return res.status(404).json({ error: "Commande non trouvée." });

  order.status = status;
  res.json({ success: true, order });
});

// --- Server-Side Gemini Assistance Route ---
app.post("/api/gemini/chat", async (req, res) => {
  const { messages, userProfile } = req.body;
  
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Format des messages invalide." });
  }

  try {
    const ai = getGeminiClient();

    // Create a concise prompt about our products to ground the AI model on real options!
    const availableEnterpriseProducts = products.filter(p => p.sellerType === 'entreprise');
    
    const contextPrompt = `Tu es l'assistant de choix intelligent et conseiller commercial pour notre plateforme startup multi-profils.
    L'utilisateur actuel est un client nommé: ${userProfile?.name || 'Visiteur'}.
    Ton but est de l'aider pas-à-pas à faire les meilleurs choix de produits, d'expliquer les spécialités des différents types d'entreprises (supermarchés, marchés, alimentations, restaurants, secrétariats, hôtels, etc.) et de l'aider à trouver les opportunités idéales.
    
    Voici les produits réels actuellement listés sur notre plateforme par les entreprises:
    ${availableEnterpriseProducts.map(p => `- [ID: ${p.id}] "${p.title}" de l'entreprise "${p.sellerName}" (${p.category}) au prix de ${p.price} FCFA par ${p.unit}. Description: ${p.description} (Stock: ${p.stock})`).join('\n')}
    
    Consignes importantes pour tes réponses:
    1. Sois très courtois, chaleureux, professionnel et encourageant.
    2. Guide activement les choix de l'utilisateur en lui recommandant expressément certains des produits ci-dessus si sa demande y correspond.
    3. Si l'utilisateur pose une question sans rapport direct avec les produits, réponds poliment tout en le redirigeant vers notre catalogue de services (restaurants locaux comme "Chez Marie l'Africaine", hôtels comme "Hôtel Royal", services de documents).
    4. Réponds toujours en FRANÇAIS. Garde tes explications claires, structurées et sans jargon inutile.
    `;

    // Format history for the generateContent call
    // The messages array is passed as a format of string or structured objects
    const lastMessage = messages[messages.length - 1];
    
    // We can compile history into a cohesive prompt
    let chatHistory = "Historique de la conversation:\n";
    messages.slice(0, -1).forEach((msg: { sender: string; text: string }) => {
      chatHistory += `${msg.sender === 'user' ? 'Client' : 'Conseiller IA'}: ${msg.text}\n`;
    });
    chatHistory += `Client actuel: ${lastMessage.text}`;

    if (process.env.GEMINI_API_KEY) {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: chatHistory,
        config: {
          systemInstruction: contextPrompt,
          temperature: 0.7,
        }
      });

      res.json({ text: response.text });
    } else {
      // Mock AI response if API key is not yet set
      console.log("Mocking response due to missing API key");
      const lower = lastMessage.text.toLowerCase();
      let responseText = `Bonjour ${userProfile?.name || ''} ! Je suis ravi de vous conseiller. `;
      
      if (lower.includes("poisson") || lower.includes("manger") || lower.includes("faim") || lower.includes("attiéké") || lower.includes("tiep")) {
        responseText += "Je vous recommande vivement d'opter pour le savoureux **Plat d'Attiéké au poisson braisé** ou l'authentique **Plat de Tiep bou dienn** chez *Chez Marie l'Africaine* (un de nos meilleurs restaurants partenaires !). Ils sont fraîchement préparés d'aujourd'hui.";
      } else if (lower.includes("lait") || lower.includes("lessive") || lower.includes("supermarché")) {
        responseText += "Pour vos courses, vous devriez choisir le **Lait entier premium** ou le bidon de **Lessive liquide Éco+** de chez *Prestige Market*. C'est le supermarché l'un de nos partenaires phares.";
      } else if (lower.includes("chambre") || lower.includes("dormir") || lower.includes("hôtel")) {
        responseText += "Si vous cherchez un hébergement haut de gamme, l'**Hôtel Royal Résidence** propose en ce moment une magnifique **Chambre Deluxe Single** pour 65,000 FCFA/nuitée avec petit-déjeuner et accès Wi-Fi haut débit.";
      } else if (lower.includes("emploi") || lower.includes("job") || lower.includes("recrute")) {
        responseText += "D'excellentes opportunités d'emploi sont actuellement disponibles ! Les entreprises comme *Chez Marie l'Africaine* recherchent un **Chef Cuisinier Adjoint** et *Hôtel Royal Résidence* cherche un **Réceptionniste de nuit**. N'hésitez pas à poser votre candidature !";
      } else {
        responseText += "Notre plateforme regroupe des entreprises fantastiques. Par exemple, si vous cherchez des repas, jetez un œil chez *Chez Marie l'Africaine*, ou pour vos impressions, optez pour *Pro-Doc Services*. Comment puis-je vous guider aujourd'hui ?";
      }

      res.json({ text: responseText, isMock: true });
    }

  } catch (err: any) {
    console.error("Gemini Error:", err);
    res.status(500).json({ error: "Une erreur est survenue lors de l'appel à l'assistant intelligent." });
  }
});


// --- Serve Built Files in Production & Vite in Dev ---

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    // Mount Vite's middleware
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Startup App Server] Running on http://localhost:${PORT}`);
  });
}

startServer();
