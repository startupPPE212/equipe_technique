import React, { useState } from 'react';
import { UserProfile, ProfileType, EnterpriseType, SupplierType } from '../types';
import { Shield, Sparkles, User, Building2, Tractor, LogIn, UserPlus } from 'lucide-react';

interface AuthScreenProps {
  onLoginSuccess: (user: UserProfile) => void;
  availableUsers: UserProfile[];
  onRefreshState: () => void;
}

export default function AuthScreen({ onLoginSuccess, availableUsers, onRefreshState }: AuthScreenProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [profileType, setProfileType] = useState<ProfileType>('client');
  const [enterpriseType, setEnterpriseType] = useState<EnterpriseType>('supermarche');
  const [supplierType, setSupplierType] = useState<SupplierType>('agriculteur');
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    setLoading(true);
    setErrorMessage('');
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Erreur d\'identification');
      }

      onLoginSuccess(data.user);
    } catch (err: any) {
      setErrorMessage(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');
    
    if (!name || !email) {
      setErrorMessage('Veuillez remplir les champs obligatoires (Nom et E-mail).');
      return;
    }

    setLoading(true);
    try {
      const payload = {
        name,
        email,
        profileType,
        enterpriseType: profileType === 'entreprise' ? enterpriseType : undefined,
        supplierType: profileType === 'fournisseur' ? supplierType : undefined,
        description,
        address,
        phone,
      };

      const response = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Erreur lors de l\'inscription');
      }

      setSuccessMessage('Compte créé avec succès ! Connectez-vous maintenant.');
      setEmail(payload.email);
      setIsRegistering(false);
      onRefreshState();
    } catch (err: any) {
      setErrorMessage(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Preset quick Logins
  const demoUsers = [
    { label: "📍 Client: Jean Dupont", user: availableUsers.find(u => u.id === 'c1') || availableUsers.find(u => u.profileType === 'client') },
    { label: "🍔 Resto: Chez Marie", user: availableUsers.find(u => u.id === 'e2') || availableUsers.find(u => u.enterpriseType === 'restaurant') },
    { label: "🏪 Hyper: Prestige Market", user: availableUsers.find(u => u.id === 'e1') || availableUsers.find(u => u.enterpriseType === 'supermarche') },
    { label: "🌾 Fournisseur: Gérard (Agri)", user: availableUsers.find(u => u.id === 's1') || availableUsers.find(u => u.supplierType === 'agriculteur') },
    { label: "🪵 Fournisseur: Koffi (Artisan)", user: availableUsers.find(u => u.id === 's2') || availableUsers.find(u => u.supplierType === 'artisan') }
  ].filter(u => u.user !== undefined);

  return (
    <div id="auth-screen-container" className="min-h-screen bg-slate-950 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 text-slate-100 font-sans">
      <div className="max-w-4xl w-full mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        
        {/* Left column - Brand & App Presentation */}
        <div id="auth-left-brand" className="md:col-span-5 flex flex-col justify-center space-y-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-indigo-600 rounded-2xl shadow-indigo-500/30 shadow-lg text-white">
              <Sparkles className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-extrabold tracking-tight text-white bg-clip-text bg-linear-to-r from-white via-indigo-200 to-indigo-400">
                StartupConnect
              </h1>
              <p className="text-xs text-indigo-400 font-medium uppercase tracking-widest">Écosystème B2B2C</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-slate-200">Une seule plateforme, trois profils interconnectés.</h2>
            <p className="text-sm text-slate-400 leading-relaxed">
              StartupConnect révolutionne l'économie de proximité en reliant intelligemment les clients locaux, les commerces de toutes catégories et les producteurs régionaux.
            </p>
          </div>

          <div className="border-t border-slate-800 pt-6 space-y-3">
            <div className="flex items-start space-x-3 text-sm text-slate-400">
              <span className="flex-shrink-0 w-5 h-5 bg-indigo-900/50 text-indigo-300 rounded-full flex items-center justify-center text-xs font-bold">1</span>
              <span><strong>Clients :</strong> Achetez localement, trouvez un emploi et laissez-vous conseiller par notre IA.</span>
            </div>
            <div className="flex items-start space-x-3 text-sm text-slate-400">
              <span className="flex-shrink-0 w-5 h-5 bg-indigo-900/50 text-indigo-300 rounded-full flex items-center justify-center text-xs font-bold">2</span>
              <span><strong>Entreprises :</strong> Gérez vos stocks, publiez des offres d'emploi et commandez vos matières premières auprès des fournisseurs.</span>
            </div>
            <div className="flex items-start space-x-3 text-sm text-slate-400">
              <span className="flex-shrink-0 w-5 h-5 bg-indigo-900/50 text-indigo-300 rounded-full flex items-center justify-center text-xs font-bold">3</span>
              <span><strong>Fournisseurs :</strong> Vendez vos récoltes et produits artisanaux directement aux entreprises partenaires.</span>
            </div>
          </div>
        </div>

        {/* Right column - Auth Box */}
        <div id="auth-right-form-box" className="md:col-span-7 bg-slate-900/80 rounded-3xl border border-slate-800 p-8 shadow-2xl relative overflow-hidden backdrop-blur-xs">
          <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/5 rounded-full blur-3xl -mr-12 -mt-12"></div>
          
          <div className="flex space-x-1 bg-slate-950 p-1.5 rounded-2xl mb-6">
            <button
              id="auth-toggle-login-btn"
              onClick={() => { setIsRegistering(false); setErrorMessage(''); }}
              className={`flex-1 flex items-center justify-center space-x-2 py-2.5 px-4 rounded-xl text-sm font-medium transition duration-200 ${!isRegistering ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'}`}
            >
              <LogIn className="w-4 h-4" />
              <span>Connexion</span>
            </button>
            <button
              id="auth-toggle-register-btn"
              onClick={() => { setIsRegistering(true); setErrorMessage(''); }}
              className={`flex-1 flex items-center justify-center space-x-2 py-2.5 px-4 rounded-xl text-sm font-medium transition duration-200 ${isRegistering ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'}`}
            >
              <UserPlus className="w-4 h-4" />
              <span>Créer un compte</span>
            </button>
          </div>

          {errorMessage && (
            <div className="mb-4 p-4 rounded-xl bg-red-900/30 border border-red-800/50 text-red-300 text-sm">
              {errorMessage}
            </div>
          )}

          {successMessage && (
            <div className="mb-4 p-4 rounded-xl bg-emerald-900/30 border border-emerald-800/50 text-emerald-300 text-sm">
              {successMessage}
            </div>
          )}

          {/* Form Content */}
          {!isRegistering ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1.5">Adresse e-mail du compte</label>
                <input
                  id="login-email-input"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="ex: client1@email.com ou marie@resto.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-sm"
                  required
                />
              </div>

              <button
                id="login-submit-btn"
                type="submit"
                disabled={loading}
                className="w-full bg-indigo-600 hover:bg-indigo-500 transition font-semibold text-white py-3 rounded-xl shadow-lg shadow-indigo-600/20 text-sm flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                {loading ? 'Connexion...' : 'Entrer sur mon espace'}
              </button>

              {/* Demo accounts picker - SUPER IMPORTANT for AI Studio Instant testability */}
              <div className="mt-8 border-t border-slate-800/60 pt-6">
                <span className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">CONXION RAPIDE (MODE DÉMO)</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {demoUsers.map((d, idx) => (
                    <button
                      id={`preset-auth-${idx}`}
                      key={idx}
                      type="button"
                      onClick={() => {
                        if (d.user) onLoginSuccess(d.user);
                      }}
                      className="text-left bg-slate-950/60 hover:bg-slate-950 border border-slate-800/50 hover:border-slate-700/80 rounded-xl p-2.5 transition text-xs flex flex-col justify-between hover:text-indigo-300"
                    >
                      <span className="font-semibold block truncate text-slate-200">{d.label}</span>
                      <span className="text-[10px] text-slate-500 block truncate">{d.user?.email}</span>
                    </button>
                  ))}
                </div>
              </div>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Type de Profil</label>
                  <select
                    id="register-profile-type-select"
                    value={profileType}
                    onChange={(e) => setProfileType(e.target.value as ProfileType)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                  >
                    <option value="client">👤 Client (Acheteur et Recherche d'emploi)</option>
                    <option value="entreprise">🏢 Entreprise (Vente aux clients, Offres d'emploi)</option>
                    <option value="fournisseur">🌾 Fournisseur (Vente aux entreprises)</option>
                  </select>
                </div>

                {profileType === 'entreprise' && (
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-slate-300 mb-1">Catégorie d'Entreprise</label>
                    <select
                      id="register-enterprise-type-select"
                      value={enterpriseType}
                      onChange={(e) => setEnterpriseType(e.target.value as EnterpriseType)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                    >
                      <option value="supermarche">🛒 Supermarché</option>
                      <option value="marche">🏛️ Marché de quartier</option>
                      <option value="alimentation">🍎 Alimentation / Épicerie</option>
                      <option value="restaurant">🍳 Restaurant / Café</option>
                      <option value="secretariat">💻 Secrétariat / Bureautique</option>
                      <option value="hotel">🏨 Hôtel / Hébergement</option>
                      <option value="autre">✨ Autre activité commerciale</option>
                    </select>
                  </div>
                )}

                {profileType === 'fournisseur' && (
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-slate-300 mb-1">Spécialité Fournisseur</label>
                    <select
                      id="register-supplier-type-select"
                      value={supplierType}
                      onChange={(e) => setSupplierType(e.target.value as SupplierType)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-sm focus:outline-none focus:border-indigo-500"
                    >
                      <option value="agriculteur">🚜 Agriculteur / Maraîcher</option>
                      <option value="artisan">🪵 Artisan d'art / Fabricant</option>
                      <option value="eleveur">🐑 Éleveur de bétail / Volaille</option>
                      <option value="autre">📦 Autre fournisseur</option>
                    </select>
                  </div>
                )}

                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Nom / Enseigne *</label>
                  <input
                    id="register-name-input"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Nom du profil ou Commerce"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>

                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Adresse e-mail *</label>
                  <input
                    id="register-email-input"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="ex: contact@entreprise.com"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>

                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Adresse physique</label>
                  <input
                    id="register-address-input"
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Ville, quartier"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-sm font-medium text-slate-300 mb-1">N° de Téléphone</label>
                  <input
                    id="register-phone-input"
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+225 01020304"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Description / Activité</label>
                  <textarea
                    id="register-description-input"
                    rows={2}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Parlez-nous en quelques mots de vos produits, services ou besoins de proximité..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-indigo-500 resize-none"
                  />
                </div>
              </div>

              <button
                id="register-submit-btn"
                type="submit"
                disabled={loading}
                className="w-full mt-2 bg-indigo-600 hover:bg-indigo-500 transition font-semibold text-white py-2.5 rounded-xl shadow-lg shadow-indigo-600/20 text-sm flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                {loading ? 'Inscription...' : "Enregistrer mon profil et s'inscrire"}
              </button>
            </form>
          )}

        </div>
      </div>
    </div>
  );
}
