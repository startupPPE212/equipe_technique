import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, Product, JobOffer, Order, ChatMessage, EnterpriseType } from '../types';
import { ShoppingBag, Sparkles, Briefcase, ListTodo, Send, MessageSquare, MapPin, BadgePercent, CheckCircle2, ChevronRight, ShoppingCart } from 'lucide-react';

interface ClientDashboardProps {
  user: UserProfile;
  products: Product[];
  jobOffers: JobOffer[];
  orders: Order[];
  onRefreshState: () => void;
}

export default function ClientDashboard({ user, products, jobOffers, orders, onRefreshState }: ClientDashboardProps) {
  const [activeTab, setActiveTab] = useState<'shop' | 'ai-chat' | 'jobs' | 'orders'>('shop');
  const [shopFilter, setShopFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Basket & Order Simulation
  const [cart, setCart] = useState<{ [productId: string]: number }>({});
  const [orderLoading, setOrderLoading] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState('');

  // AI Chat State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { id: '1', sender: 'ai', text: `Bonjour ${user.name} ! Je suis votre conseiller d'achat intelligent. Je peux vous guider vers le bon produit, vous renseigner sur les spécialités de nos restaurants démo (comme "Chez Marie") ou vous aider à décrypter les offres d'emploi actives. Que cherchez-vous aujourd'hui ?`, timestamp: new Date().toLocaleTimeString() }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Job Application simulation
  const [appliedJobs, setAppliedJobs] = useState<string[]>([]);
  const [appStatusMessage, setAppStatusMessage] = useState<{ [jobId: string]: string }>({});

  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, chatLoading]);

  // Enterprise Products only
  const enterpriseProducts = products.filter(p => p.sellerType === 'entreprise');

  // Sector categorization helpers
  const filteredProducts = enterpriseProducts.filter(p => {
    // We can fetch user details or categorize products based on enterprise type
    if (shopFilter === 'all') return true;
    
    // In our seed, seller category/enterpriseType maps are stored
    const seller = products.find(prod => prod.sellerId === p.sellerId);
    if (!seller) return true;
    
    // Match categories or title
    return p.category.toLowerCase().includes(shopFilter.toLowerCase()) || 
           p.title.toLowerCase().includes(shopFilter.toLowerCase());
  }).filter(p => p.title.toLowerCase().includes(searchQuery.toLowerCase()) || p.description.toLowerCase().includes(searchQuery.toLowerCase()));

  // Add to basket
  const addToCart = (productId: string, maxStock: number) => {
    const currentQty = cart[productId] || 0;
    if (currentQty < maxStock) {
      setCart({ ...cart, [productId]: currentQty + 1 });
    }
  };

  const removeFromCart = (productId: string) => {
    const currentQty = cart[productId] || 0;
    if (currentQty <= 1) {
      const updated = { ...cart };
      delete updated[productId];
      setCart(updated);
    } else {
      setCart({ ...cart, [productId]: currentQty - 1 });
    }
  };

  // Place order
  const handleCheckout = async (productId: string, quantity: number) => {
    setOrderLoading(true);
    setOrderSuccess('');
    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          buyerId: user.id,
          productId,
          quantity
        })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Erreur d\'achat');

      setCart(prev => {
        const u = { ...prev };
        delete u[productId];
        return u;
      });
      setOrderSuccess(`Achat de ${quantity} x produit validé avec succès !`);
      setTimeout(() => setOrderSuccess(''), 5000);
      onRefreshState();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setOrderLoading(false);
    }
  };

  // Chat with Gemini Advisor
  const handleSendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || chatLoading) return;

    const userMsg = chatInput.trim();
    setChatInput('');
    
    const newUserMessage: ChatMessage = {
      id: Math.random().toString(),
      sender: 'user',
      text: userMsg,
      timestamp: new Date().toLocaleTimeString()
    };

    setChatMessages(prev => [...prev, newUserMessage]);
    setChatLoading(true);

    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...chatMessages, newUserMessage].map(m => ({ sender: m.sender, text: m.text })),
          userProfile: user
        })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error);

      setChatMessages(prev => [...prev, {
        id: Math.random().toString(),
        sender: 'ai',
        text: data.text,
        timestamp: new Date().toLocaleTimeString()
      }]);
    } catch (err: any) {
      setChatMessages(prev => [...prev, {
        id: Math.random().toString(),
        sender: 'ai',
        text: "Désolé, je rencontre quelques soucis de connexion. Recourez aux raccourcis d'achat ci-dessous pour commander !",
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setChatLoading(false);
    }
  };

  // Apply to Job
  const handleApplyJob = (jobId: string) => {
    setAppliedJobs(prev => [...prev, jobId]);
    setAppStatusMessage(prev => ({ ...prev, [jobId]: "Candidature envoyée avec succès ! L'entreprise vous contactera si votre profil correspond." }));
  };

  return (
    <div id="client-dashboard-root" className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start font-sans">
      
      {/* Dynamic Tab Navigation Cards */}
      <div id="client-tabs-container" className="lg:col-span-3 space-y-3">
        <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-4">
          <div className="flex items-center space-x-3 mb-4 pb-4 border-b border-slate-800/60">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center font-bold">
              👤
            </div>
            <div>
              <h3 className="font-semibold text-sm text-slate-100">{user.name}</h3>
              <span className="text-xs text-indigo-400 bg-indigo-950/40 px-2 py-0.5 rounded-full font-medium">Profil Client</span>
            </div>
          </div>

          <div className="space-y-1">
            <button
              id="tab-client-shop"
              onClick={() => setActiveTab('shop')}
              className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-left text-sm transition duration-200 ${activeTab === 'shop' ? 'bg-indigo-600 font-semibold text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Boutique de Proximité</span>
            </button>
            <button
              id="tab-client-ai-chat"
              onClick={() => setActiveTab('ai-chat')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-sm transition duration-200 ${activeTab === 'ai-chat' ? 'bg-indigo-600 font-semibold text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
            >
              <span className="flex items-center space-x-3">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Discussion IA Choix</span>
              </span>
              <span className="bg-amber-500/15 text-amber-400 text-[10px] font-bold px-1.5 py-0.5 rounded-sm">LIVE</span>
            </button>
            <button
              id="tab-client-jobs"
              onClick={() => setActiveTab('jobs')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-sm transition duration-200 ${activeTab === 'jobs' ? 'bg-indigo-600 font-semibold text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
            >
              <span className="flex items-center space-x-3">
                <Briefcase className="w-4 h-4" />
                <span>Offres d'Emploi</span>
              </span>
              <span className="bg-indigo-500/30 text-indigo-200 text-[10px] rounded-full px-2">{jobOffers.length}</span>
            </button>
            <button
              id="tab-client-orders"
              onClick={() => setActiveTab('orders')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-sm transition duration-200 ${activeTab === 'orders' ? 'bg-indigo-600 font-semibold text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
            >
              <span className="flex items-center space-x-3">
                <ListTodo className="w-4 h-4" />
                <span>Mes Commandes</span>
              </span>
              <span className="bg-slate-800 text-slate-300 text-[10px] rounded-full px-2">{orders.filter(o => o.buyerId === user.id).length}</span>
            </button>
          </div>
        </div>

        {/* Small AI Tip Promo banner */}
        <div className="bg-linear-to-b from-indigo-950/20 to-slate-950 border border-indigo-900/30 p-4 rounded-2xl flex flex-col justify-between">
          <div className="flex items-center space-x-2 text-indigo-300 mb-2">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-xs font-bold uppercase tracking-wider">Conseil IA</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed mb-3">
            Vous hésitez entre l'Attiéké de Chez Marie ou les produits du Prestige Market ? Accédez à la <strong>Discussion IA</strong> pour une recommandation culinaire ou un accompagnement d'achat local sur mesure !
          </p>
          <button
            id="client-dashboard-quick-switch-to-ai"
            onClick={() => setActiveTab('ai-chat')}
            className="w-full py-1.5 text-center text-[11px] font-semibold bg-indigo-900/40 hover:bg-indigo-900/60 rounded-lg text-indigo-300 transition"
          >
            Consulter l'IA Conseillère →
          </button>
        </div>
      </div>

      {/* Primary Workspace Window */}
      <div id="client-workspace-container" className="lg:col-span-9 bg-slate-900 border border-slate-800 rounded-3xl p-6 min-h-[550px] relative">
        
        {orderSuccess && (
          <div className="mb-4 p-4 rounded-xl bg-emerald-950/50 border border-emerald-800/80 text-emerald-300 text-sm flex items-center space-x-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span>{orderSuccess}</span>
          </div>
        )}

        {/* TAB 1: SHOPPING */}
        {activeTab === 'shop' && (
          <div id="client-shop-view" className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/60 pb-4">
              <div>
                <h1 className="text-xl font-bold text-white flex items-center space-x-2">
                  <ShoppingBag className="w-5 h-5 text-indigo-400" />
                  <span>Boutique de Proximité</span>
                </h1>
                <p className="text-xs text-slate-400">Commandez des produits frais, des repas et des services proposés par des commerçants qualifiés.</p>
              </div>

              {/* Simple Search */}
              <input
                id="shop-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher tomates, lait, attiéké..."
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Quick Sector Filters */}
            <div className="flex flex-wrap gap-1.5">
              {[
                { label: 'Tous les commerces', value: 'all' },
                { label: 'Repas / Resto', value: 'Repas' },
                { label: 'Courses / Aliments', value: 'Alimentation' },
                { label: 'Hébergement / Hôtels', value: 'Hébergement' },
                { label: 'Légumes / Marchés', value: 'Légumes' },
                { label: 'Entretien & Ménage', value: 'Entretien' },
                { label: 'Bureautique', value: 'Bureautique' }
              ].map((f) => (
                <button
                  id={`filter-shop-${f.value}`}
                  key={f.value}
                  onClick={() => setShopFilter(f.value)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${shopFilter === f.value ? 'bg-indigo-900/50 text-indigo-200 border border-indigo-500/40 shadow-sm' : 'bg-slate-950 text-slate-400 hover:text-white border border-transparent'}`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Products grid */}
            {filteredProducts.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                Aucun produit ne correspond à vos filtres ou à votre recherche.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredProducts.map((p) => {
                  const qtyInCart = cart[p.id] || 0;
                  return (
                    <div id={`product-card-${p.id}`} key={p.id} className="bg-slate-950/50 border border-slate-800/80 rounded-2xl p-4 flex flex-col justify-between hover:border-slate-700/80 transition">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-sm bg-indigo-950 text-indigo-300">
                            {p.category}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono">
                            Par • {p.sellerName}
                          </span>
                        </div>
                        <h3 className="font-semibold text-sm text-slate-100 mb-1">{p.title}</h3>
                        <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mb-3">{p.description}</p>
                      </div>

                      <div className="border-t border-slate-900 pt-3 flex items-center justify-between">
                        <div>
                          <span className="text-md font-bold text-indigo-400">{p.price.toLocaleString()} FCFA</span>
                          <span className="text-[10px] text-slate-500 block">le/la {p.unit}</span>
                        </div>

                        {p.stock === 0 ? (
                          <span className="text-xs text-red-400 bg-red-950/20 px-2.5 py-1 rounded-lg">Épuisé</span>
                        ) : (
                          <div className="flex items-center space-x-1">
                            {qtyInCart > 0 ? (
                              <div className="flex items-center space-x-2 bg-slate-900 rounded-lg border border-slate-800 p-1">
                                <button
                                  id={`remove-cart-btn-${p.id}`}
                                  onClick={() => removeFromCart(p.id)}
                                  className="w-6 h-6 rounded-md hover:bg-slate-800 text-xs text-slate-300 flex items-center justify-center transition"
                                >
                                  -
                                </button>
                                <span className="text-xs font-bold text-slate-100">{qtyInCart}</span>
                                <button
                                  id={`add-cart-btn-more-${p.id}`}
                                  onClick={() => addToCart(p.id, p.stock)}
                                  className="w-6 h-6 rounded-md hover:bg-slate-800 text-xs text-slate-300 flex items-center justify-center transition"
                                  disabled={qtyInCart >= p.stock}
                                >
                                  +
                                </button>
                                <button
                                  id={`checkout-cart-btn-${p.id}`}
                                  onClick={() => handleCheckout(p.id, qtyInCart)}
                                  className="ml-1 bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-md transition"
                                >
                                  Valider
                                </button>
                              </div>
                            ) : (
                              <button
                                id={`add-cart-btn-first-${p.id}`}
                                onClick={() => addToCart(p.id, p.stock)}
                                className="bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-850 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-200 transition flex items-center space-x-1.5"
                              >
                                <ShoppingCart className="w-3.5 h-3.5 text-indigo-400" />
                                <span>Acheter</span>
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: AI DISCUSSION CHART */}
        {activeTab === 'ai-chat' && (
          <div id="client-ai-view" className="flex flex-col h-[500px]">
            <div className="border-b border-slate-800 pb-3 mb-4 flex items-center justify-between">
              <div>
                <h1 className="text-lg font-bold text-white flex items-center space-x-2">
                  <Sparkles className="w-5 h-5 text-amber-400" />
                  <span>Discussion IA & Choix de Produit</span>
                </h1>
                <p className="text-xs text-slate-400">L'IA est informée en temps réel de tous les produits listés par les boutiques (ex: Prestige Market, Chez Marie, Hôtel Royal).</p>
              </div>
              <button
                id="clear-chat-btn"
                onClick={() => setChatMessages([
                  { id: '1', sender: 'ai', text: `Bonjour ${user.name} ! Qu'aimeriez-vous savoir sur nos produits ou sur les commerces aujourd'hui ?`, timestamp: new Date().toLocaleTimeString() }
                ])}
                className="text-slate-500 hover:text-slate-300 text-xs bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 transition"
              >
                Réinitialiser
              </button>
            </div>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto bg-slate-950/70 border border-slate-850 rounded-2xl p-4 space-y-4 mb-4">
              {chatMessages.map((msg) => (
                <div id={`chat-msg-${msg.id}`} key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${msg.sender === 'user' ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-slate-900 text-slate-100 rounded-bl-none border border-slate-800/80 shadow-md'}`}>
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-[10px] font-bold text-indigo-200/90 uppercase">{msg.sender === 'user' ? 'Moi' : 'Conseiller IA de Proximité'}</span>
                      <span className="text-[9px] text-slate-400">{msg.timestamp}</span>
                    </div>
                    <div className="whitespace-pre-wrap">{msg.text}</div>
                  </div>
                </div>
              ))}
              {chatLoading && (
                <div className="flex justify-start">
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-bl-none px-4 py-3 text-sm max-w-[80%] text-slate-400 flex items-center space-x-2 shadow-md">
                    <span className="animate-bounce">●</span>
                    <span className="animate-bounce delay-100">●</span>
                    <span className="animate-bounce delay-200">●</span>
                    <span className="text-xs ml-1">L'IA consulte les commerces de proximité...</span>
                  </div>
                </div>
              )}
              <div ref={chatBottomRef}></div>
            </div>

            {/* Suggestion Chips */}
            <div className="mb-3 flex flex-wrap gap-2">
              <span className="text-xs text-slate-500 self-center">Idées :</span>
              {[
                "Qu'est-ce qu'on peut manger chez Chez Marie ?",
                "J'ai besoin d'une chambre d'hôtel de luxe",
                "Quels sont les produits de Prestige Market ?",
                "Y a-t-il des offres d'emploi pour moi ?"
              ].map((s, idx) => (
                <button
                  id={`chat-suggestion-${idx}`}
                  key={idx}
                  onClick={() => setChatInput(s)}
                  className="bg-slate-950/80 hover:bg-slate-950 border border-slate-850 hover:border-slate-800 rounded-xl px-2.5 py-1 text-[11px] text-slate-400 hover:text-indigo-300 transition"
                >
                  {s}
                </button>
              ))}
            </div>

            {/* Input Form */}
            <form onSubmit={handleSendChatMessage} className="flex space-x-2">
              <input
                id="chat-user-text-input"
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Posez votre question à l'assistant IA..."
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                required
              />
              <button
                id="chat-send-btn"
                type="submit"
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-5 rounded-xl shadow-lg shadow-indigo-600/20 flex items-center justify-center transition"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}

        {/* TAB 3: JOB OFFERS */}
        {activeTab === 'jobs' && (
          <div id="client-jobs-view" className="space-y-6">
            <div className="border-b border-slate-800/60 pb-4">
              <h1 className="text-xl font-bold text-white flex items-center space-x-2">
                <Briefcase className="w-5 h-5 text-indigo-400" />
                <span>Offres d'Emploi Actives</span>
              </h1>
              <p className="text-xs text-slate-400">Opportunités de carrières publiées par les entreprises locales. Seuls les clients peuvent postuler.</p>
            </div>

            {jobOffers.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                Aucune offre d'emploi active pour le moment.
              </div>
            ) : (
              <div className="space-y-4">
                {jobOffers.map((j) => {
                  const hasApplied = appliedJobs.includes(j.id);
                  return (
                    <div id={`job-card-${j.id}`} key={j.id} className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700/60 transition">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                        <div>
                          <span className="text-[10px] font-bold tracking-wider text-indigo-400 uppercase bg-indigo-950/40 px-2 py-0.5 rounded-sm">
                            🏬 {j.companyType.toUpperCase()}
                          </span>
                          <h3 className="font-bold text-md text-slate-100 mt-1">{j.title}</h3>
                          <p className="text-xs text-slate-400">Proposé par <strong className="text-slate-200">{j.companyName}</strong></p>
                        </div>
                        <div className="text-right sm:text-right">
                          <span className="text-sm font-bold text-emerald-400 block">{j.salary}</span>
                          <span className="text-[10px] text-slate-500 flex items-center justify-end sm:justify-end gap-1">
                            <MapPin className="w-3 h-3" /> {j.location}
                          </span>
                        </div>
                      </div>

                      <p className="text-xs text-slate-300 mb-4 leading-relaxed">{j.description}</p>

                      <div className="mb-4">
                        <span className="block text-xs font-semibold text-slate-400 mb-1.5">Exigences requises :</span>
                        <div className="flex flex-wrap gap-1.5">
                          {j.requirements.map((req, idx) => (
                            <span id={`req-badge-${idx}`} key={idx} className="bg-slate-900 border border-slate-800 text-slate-300 text-[10px] px-2.5 py-1 rounded-full">
                              • {req}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="border-t border-slate-900/60 pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <span className="text-[10px] text-slate-500">Publiée le : {j.createdAt}</span>
                        {hasApplied ? (
                          <div className="bg-indigo-950/30 text-indigo-300 border border-indigo-900/50 rounded-xl px-4 py-2 text-xs">
                            {appStatusMessage[j.id]}
                          </div>
                        ) : (
                          <button
                            id={`apply-job-btn-${j.id}`}
                            onClick={() => handleApplyJob(j.id)}
                            className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-4 py-2 rounded-xl shadow-md transition"
                          >
                            Postuler à cette offre d'emploi
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: PERSONAL ORDERS */}
        {activeTab === 'orders' && (
          <div id="client-orders-view" className="space-y-6">
            <div className="border-b border-slate-800/60 pb-4">
              <h1 className="text-xl font-bold text-white flex items-center space-x-2">
                <ListTodo className="w-5 h-5 text-indigo-400" />
                <span>Mes Achats & Commandes de proximité</span>
              </h1>
              <p className="text-xs text-slate-400">Suivi en direct des commandes passées auprès de nos entreprises partenaires.</p>
            </div>

            {orders.filter(o => o.buyerId === user.id).length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                Vous n'avez pas encore effectué d'achats sur la plateforme.
              </div>
            ) : (
              <div className="space-y-3">
                {orders.filter(o => o.buyerId === user.id).map((o) => (
                  <div id={`order-card-${o.id}`} key={o.id} className="bg-slate-950/40 border border-slate-850 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-slate-800 transition">
                    <div>
                      <div className="flex items-center space-x-2 text-xs mb-1">
                        <span className="text-slate-500 font-mono">ID: {o.id}</span>
                        <span className="text-slate-600">•</span>
                        <span className="text-indigo-300 font-semibold">Vendeur: {o.sellerName}</span>
                      </div>
                      <h4 className="font-semibold text-slate-200 text-sm">{o.productTitle}</h4>
                      <p className="text-xs text-slate-400">Quantité : {o.quantity} • Prix : {(o.price * o.quantity).toLocaleString()} FCFA</p>
                    </div>

                    <div className="flex items-center space-x-3 self-end sm:self-center">
                      <span className="text-[10px] text-slate-500">{new Date(o.createdAt).toLocaleDateString()}</span>
                      
                      {o.status === 'pending' && <span className="bg-amber-950/40 text-amber-300 border border-amber-900/50 text-[10px] uppercase font-bold px-2.5 py-1 rounded-full">⏳ En attente</span>}
                      {o.status === 'accepted' && <span className="bg-indigo-950/40 text-indigo-300 border border-indigo-900/50 text-[10px] uppercase font-bold px-2.5 py-1 rounded-full">✓ Confirmé</span>}
                      {o.status === 'shipped' && <span className="bg-blue-950/40 text-blue-300 border border-blue-900/50 text-[10px] uppercase font-bold px-2.5 py-1 rounded-full">🚚 En livraison</span>}
                      {o.status === 'delivered' && <span className="bg-emerald-950/40 text-emerald-300 border border-emerald-800/50 text-[10px] uppercase font-bold px-2.5 py-1 rounded-full">🎉 Reçu</span>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
