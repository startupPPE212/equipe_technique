import React, { useState } from 'react';
import { UserProfile, Product, JobOffer, Order, Vente } from '../types';
import { Shield, LayoutDashboard, PlusCircle, Briefcase, FileText, Tractor, ShoppingCart, Truck, CheckCircle2, Trash2, Sparkles, Plus, Minus, AlertTriangle, TrendingUp, DollarSign, Package, Check, User } from 'lucide-react';

interface BusinessDashboardProps {
  user: UserProfile;
  products: Product[];
  jobOffers: JobOffer[];
  orders: Order[];
  ventes?: Vente[];
  onRefreshState: () => void;
}

export default function BusinessDashboard({ user, products, jobOffers, orders, ventes = [], onRefreshState }: BusinessDashboardProps) {
  const [activeTab, setActiveTab] = useState<'inventory' | 'recruitment' | 'b2b-procure' | 'sales' | 'pos'>('inventory');
  
  // Product state form
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [newCategory, setNewCategory] = useState('Alimentation');
  const [newStock, setNewStock] = useState('');
  const [newUnit, setNewUnit] = useState('unité');

  // Job offer state form
  const [jobTitle, setJobTitle] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [jobSalary, setJobSalary] = useState('');
  const [jobLocation, setJobLocation] = useState(user.address || 'Local');
  const [jobRequirement, setJobRequirement] = useState('');
  const [jobReqs, setJobReqs] = useState<string[]>([]);

  const [formLoading, setFormLoading] = useState(false);
  const [formSuccess, setFormSuccess] = useState('');
  const [formError, setFormError] = useState('');

  // Local inventory & data filtered specifically for THIS isolated company account
  const myProducts = products.filter(p => p.sellerId === user.id);
  const myJobs = jobOffers.filter(j => j.companyId === user.id);
  const myIncomingOrders = orders.filter(o => o.sellerId === user.id); // From clients
  const myOutgoingOrders = orders.filter(o => o.buyerId === user.id); // For raw materials from suppliers

  // In B2B Procure view, we browse products listed by Suppliers (Fournisseurs)
  const supplierProducts = products.filter(p => p.sellerType === 'fournisseur');

  // --- POS Cashier & AI Analytics States ---
  const [posAge, setPosAge] = useState<string>('18-25');
  const [posSexe, setPosSexe] = useState<string>('Femme');
  const [posCart, setPosCart] = useState<{ produit: string; quantite: number; prix_unitaire: number; rayon: string }[]>([]);
  const [aiInsights, setAiInsights] = useState<{
    staticRecommendations: { produit: string; score: number }[];
    advancedRecommendations: { produit: string; score: number }[];
    predictionResult?: {
      bestRayon: string;
      bestScore: number;
      level: string;
      probabilities: { rayon: string; proba: number }[];
    };
  } | null>(null);

  const [posError, setPosError] = useState<{
    error: string;
    message: string;
    produit: string;
    demande: number;
    dispo: number;
  } | null>(null);
  const [posSuccess, setPosSuccess] = useState<string>('');
  const [posSubmitting, setPosSubmitting] = useState<boolean>(false);

  // Trigger recommender queries instantly on cashier input change
  React.useEffect(() => {
    if (activeTab !== 'pos') return;
    
    const queryAIInsights = async () => {
      try {
        const response = await fetch('/api/recommend', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            entreprise_id: user.id,
            age: posAge,
            sexe: posSexe,
            panier: posCart.map(i => i.produit)
          })
        });
        if (response.ok) {
          const data = await response.json();
          setAiInsights({
            staticRecommendations: data.staticRecommendations || [],
            advancedRecommendations: data.advancedRecommendations || [],
            predictionResult: data.predictionResult
          });
        }
      } catch (err) {
        console.error("Erreur de calcul de l'algorithme de recommandation:", err);
      }
    };

    const timer = setTimeout(() => {
      queryAIInsights();
    }, 150);

    return () => clearTimeout(timer);
  }, [posAge, posSexe, posCart, activeTab, user.id]);

  const handleAddPosCartItem = (p: Product) => {
    setPosSuccess('');
    setPosError(null);
    const existing = posCart.find(item => item.produit.toLowerCase() === p.title.toLowerCase());
    if (existing) {
      if (existing.quantite + 1 > p.stock) {
        setPosError({
          error: 'vente_impossible',
          message: `Stock insuffisant pour ajouter un autre "${p.title}".`,
          produit: p.title,
          demande: existing.quantite + 1,
          dispo: p.stock
        });
        return;
      }
      setPosCart(posCart.map(item => item.produit.toLowerCase() === p.title.toLowerCase() ? { ...item, quantite: item.quantite + 1 } : item));
    } else {
      if (p.stock < 1) {
        setPosError({
          error: 'vente_impossible',
          message: `Stock en rupture de stock pour "${p.title}".`,
          produit: p.title,
          demande: 1,
          dispo: p.stock
        });
        return;
      }
      setPosCart([...posCart, { produit: p.title, quantite: 1, prix_unitaire: p.price, rayon: p.category }]);
    }
  };

  const handleRemovePosCartItem = (productName: string) => {
    setPosError(null);
    setPosSuccess('');
    const existing = posCart.find(item => item.produit.toLowerCase() === productName.toLowerCase());
    if (existing && existing.quantite > 1) {
      setPosCart(posCart.map(item => item.produit.toLowerCase() === productName.toLowerCase() ? { ...item, quantite: item.quantite - 1 } : item));
    } else {
      setPosCart(posCart.filter(item => item.produit.toLowerCase() !== productName.toLowerCase()));
    }
  };

  const handleCheckoutPosCart = async (e: React.FormEvent) => {
    e.preventDefault();
    if (posCart.length === 0) return;
    setPosSubmitting(true);
    setPosError(null);
    setPosSuccess('');

    try {
      const response = await fetch('/api/ventes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          entreprise_id: user.id,
          age: posAge,
          sexe: posSexe,
          items: posCart
        })
      });

      const data = await response.json();
      if (!response.ok) {
        if (data.error === 'vente_impossible') {
          setPosError(data);
        } else {
          throw new Error(data.error || 'Erreur lors de la validation POS');
        }
      } else {
        setPosSuccess('Achat direct comptoir enregistré avec succès ! L\'inventaire a été décrémenté.');
        setPosCart([]);
        onRefreshState();
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setPosSubmitting(false);
    }
  };

  // Handle add product
  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newPrice || !newStock) return;
    
    setFormLoading(true);
    setFormError('');
    setFormSuccess('');

    try {
      const response = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sellerId: user.id,
          title: newTitle,
          description: newDescription,
          price: Number(newPrice),
          category: newCategory,
          stock: Number(newStock),
          unit: newUnit
        })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error);

      setFormSuccess('Produit ajouté à votre boutique !');
      setNewTitle('');
      setNewDescription('');
      setNewPrice('');
      setNewStock('');
      setNewUnit('unité');
      onRefreshState();
    } catch (err: any) {
      setFormError(err.message);
    } finally {
      setFormLoading(false);
    }
  };

  // Delete product
  const handleDeleteProduct = async (productId: string) => {
    if (!confirm('Voulez-vous vraiment retirer ce produit ?')) return;

    try {
      const response = await fetch(`/api/products/${productId}`, {
        method: 'DELETE'
      });
      if (response.ok) {
        onRefreshState();
      }
    } catch (err) {
      alert('Erreur lors du retrait du produit');
    }
  };

  // Add req to list temp
  const addRequirement = () => {
    if (jobRequirement.trim()) {
      setJobReqs([...jobReqs, jobRequirement.trim()]);
      setJobRequirement('');
    }
  };

  // Handle post Job Offer
  const handlePostJob = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!jobTitle || !jobDescription || !jobSalary) return;

    setFormLoading(true);
    setFormError('');
    setFormSuccess('');

    try {
      const response = await fetch('/api/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          companyId: user.id,
          title: jobTitle,
          description: jobDescription,
          salary: jobSalary,
          location: jobLocation,
          requirements: jobReqs.length > 0 ? jobReqs : ["Motivé", "Polyvalent"]
        })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error);

      setFormSuccess('Offre d\'emploi publiée avec succès ! Seuls les profils clients y ont accès.');
      setJobTitle('');
      setJobDescription('');
      setJobSalary('');
      setJobReqs([]);
      onRefreshState();
    } catch (err: any) {
      setFormError(err.message);
    } finally {
      setFormLoading(false);
    }
  };

  // Order status update (incoming clients orders)
  const handleOrderStatusUpdate = async (orderId: string, status: 'accepted' | 'shipped' | 'delivered') => {
    try {
      const response = await fetch(`/api/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (response.ok) {
        onRefreshState();
      }
    } catch (err) {
      alert('Erreur lors du changement d\'état de la commande');
    }
  };

  // Procure raw materials from supplier
  const handleProcureRawMaterials = async (productId: string, quantity: number) => {
    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          buyerId: user.id, // This enterprise is buying
          productId,
          quantity
        })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error);

      alert(`Commande d'approvisionnement envoyée avec succès au fournisseur !`);
      onRefreshState();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div id="business-dashboard-root" className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start font-sans">
      
      {/* Sidebar profile stats & Switch sub-dashboard tabs */}
      <div id="business-sidebar" className="lg:col-span-3 space-y-3">
        <div className="bg-slate-900 border border-slate-800/80 rounded-2xl p-4">
          <div className="flex items-center space-x-3 mb-4 pb-4 border-b border-slate-800/60">
            <div className="w-10 h-10 rounded-xl bg-violet-500/10 text-violet-400 flex items-center justify-center font-bold">
              🏢
            </div>
            <div>
              <h3 className="font-semibold text-sm text-slate-100">{user.name}</h3>
              <span className="text-[10px] text-violet-400 bg-violet-950/40 px-2 py-0.5 rounded-full font-semibold uppercase">
                {user.enterpriseType}
              </span>
            </div>
          </div>

          <div className="space-y-1">
            <button
              id="tab-business-inventory"
              onClick={() => { setActiveTab('inventory'); setFormSuccess(''); setFormError(''); }}
              className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-left text-sm transition duration-200 ${activeTab === 'inventory' ? 'bg-violet-600 font-semibold text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Mon Inventaire Produit</span>
            </button>
            <button
              id="tab-business-recruitment"
              onClick={() => { setActiveTab('recruitment'); setFormSuccess(''); setFormError(''); }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-sm transition duration-200 ${activeTab === 'recruitment' ? 'bg-violet-600 font-semibold text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
            >
              <span className="flex items-center space-x-3">
                <Briefcase className="w-4 h-4" />
                <span>Publier un Emploi</span>
              </span>
              <span className="bg-violet-950 text-violet-300 text-[10px] rounded-full px-2 py-0.5">{myJobs.length}</span>
            </button>
            <button
              id="tab-business-b2b"
              onClick={() => { setActiveTab('b2b-procure'); setFormSuccess(''); setFormError(''); }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-sm transition duration-200 ${activeTab === 'b2b-procure' ? 'bg-violet-600 font-semibold text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
            >
              <span className="flex items-center space-x-3">
                <Tractor className="w-4 h-4 text-emerald-400" />
                <span>Approvisionnement (B2B)</span>
              </span>
              <span className="bg-emerald-950 text-emerald-300 text-[10px] rounded-sm px-1.5 font-bold">RELATION</span>
            </button>
            <button
              id="tab-business-sales"
              onClick={() => { setActiveTab('sales'); setFormSuccess(''); setFormError(''); }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-sm transition duration-200 ${activeTab === 'sales' ? 'bg-violet-600 font-semibold text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
            >
              <span className="flex items-center space-x-3">
                <ShoppingCart className="w-4 h-4" />
                <span>Commandes Clients</span>
              </span>
              <span className="bg-violet-900 text-violet-100 text-[10px] rounded-full px-2">{myIncomingOrders.length}</span>
            </button>
            <button
              id="tab-business-pos"
              onClick={() => { setActiveTab('pos'); setFormSuccess(''); setFormError(''); setPosSuccess(''); setPosError(null); }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left text-sm transition duration-200 ${activeTab === 'pos' ? 'bg-violet-600 font-semibold text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
            >
              <span className="flex items-center space-x-3">
                <Sparkles className="w-4 h-4 text-violet-400" />
                <span className="font-medium">Caisse & Recommandations IA</span>
              </span>
              <span className="bg-linear-to-r from-indigo-500 to-violet-500 text-white text-[9px] px-1.5 py-0.5 rounded font-bold uppercase animate-pulse">SMART</span>
            </button>
          </div>
        </div>

        {/* Business Data Isolation Notice */}
        <div className="bg-violet-950/20 border border-violet-900/30 p-4 rounded-2xl">
          <div className="flex items-center space-x-2 text-violet-300 mb-2">
            <Shield className="w-4 h-4 text-violet-400" />
            <span className="text-xs font-bold uppercase tracking-wider">Sécurisation des Données</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Vos produits, commandes clients et offres de postes sont <strong>complètement isolés</strong> de toute autre entreprise ou concurrent. Vos opportunités restent confidentielles !
          </p>
        </div>
      </div>

      {/* Main workspace frame */}
      <div id="business-workspace" className="lg:col-span-9 bg-slate-900 border border-slate-800 rounded-3xl p-6 min-h-[550px]">
        {formSuccess && (
          <div className="mb-4 p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/80 text-emerald-300 text-sm">
            {formSuccess}
          </div>
        )}
        {formError && (
          <div className="mb-4 p-4 rounded-xl bg-red-950/40 border border-red-800/80 text-red-300 text-sm">
            {formError}
          </div>
        )}

        {/* TAB 1: MANAGE INVENTORY / PRODUCT */}
        {activeTab === 'inventory' && (
          <div id="business-inventory-tab" className="space-y-6">
            <div className="border-b border-slate-800/60 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-white flex items-center space-x-2">
                  <LayoutDashboard className="w-5 h-5 text-violet-400" />
                  <span>Mon Inventaire Produit / Service</span>
                </h1>
                <p className="text-xs text-slate-400">Ajoutez des produits physiques ou services locaux de proximité visibles uniquement des acheteurs clients.</p>
              </div>
            </div>

            {/* Grid system splitting layout: Left = Form add, Right = inventory list */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              
              {/* Product Listing Form */}
              <div className="md:col-span-4 bg-slate-950/40 border border-slate-850 p-4 rounded-2xl">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-350 mb-4 flex items-center space-x-1.5">
                  <PlusCircle className="w-3.5 h-3.5 text-violet-400" />
                  <span>Nouveau produit</span>
                </h3>
                
                <form onSubmit={handleAddProduct} className="space-y-3">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Nom du produit / service *</label>
                    <input
                      id="new-product-title"
                      type="text"
                      placeholder="ex: Plat de poisson braisé"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-violet-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Prix de vente (FCFA) *</label>
                    <input
                      id="new-product-price"
                      type="number"
                      placeholder="4000"
                      value={newPrice}
                      onChange={(e) => setNewPrice(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-violet-500"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Quantité Stock *</label>
                      <input
                        id="new-product-stock"
                        type="number"
                        placeholder="50"
                        value={newStock}
                        onChange={(e) => setNewStock(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-violet-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Unité</label>
                      <input
                        id="new-product-unit"
                        type="text"
                        placeholder="portion, kg, litre"
                        value={newUnit}
                        onChange={(e) => setNewUnit(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-violet-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Catégorie du Catalogue</label>
                    <select
                      id="new-product-category"
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-violet-500"
                    >
                      <option value="Repas">🍳 Repas préparé</option>
                      <option value="Alimentation">🍎 Epicerie / Aliments</option>
                      <option value="Légumes">🍍 Fruits & Légumes</option>
                      <option value="Hébergement">🏨 Services hôteliers</option>
                      <option value="Bureautique">💻 Informatique & Saisie</option>
                      <option value="Entretien">🧼 Entretien habitation</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Description</label>
                    <textarea
                      id="new-product-desc"
                      rows={2}
                      placeholder="Description soignée du produit..."
                      value={newDescription}
                      onChange={(e) => setNewDescription(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-855 rounded-lg px-2.5 py-1 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-violet-500 resize-none"
                    />
                  </div>

                  <button
                    id="add-product-submit"
                    type="submit"
                    disabled={formLoading}
                    className="w-full py-2 bg-violet-600 hover:bg-violet-500 transition text-white font-semibold rounded-lg text-xs"
                  >
                    {formLoading ? 'Création...' : 'Mettre en vente'}
                  </button>
                </form>
              </div>

              {/* My products inventory grid */}
              <div className="md:col-span-8 space-y-3">
                <span className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Mon inventaire actif ({myProducts.length})</span>
                
                {myProducts.length === 0 ? (
                  <div className="text-center py-12 text-slate-600 border border-dashed border-slate-800 rounded-2xl bg-slate-950/20">
                    Vous n'avez aucun produit enregistré. Ajoutez-en un à l'aide du formulaire.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {myProducts.map((p) => (
                      <div id={`my-prod-${p.id}`} key={p.id} className="bg-slate-950/60 border border-slate-850 rounded-xl p-3.5 flex flex-col justify-between hover:border-slate-800 transition">
                        <div>
                          <div className="flex justify-between items-start mb-1">
                            <h4 className="font-bold text-xs text-slate-200">{p.title}</h4>
                            <button
                              id={`delete-prod-btn-${p.id}`}
                              onClick={() => handleDeleteProduct(p.id)}
                              className="text-slate-500 hover:text-red-400 p-1 rounded-md transition"
                              title="Retirer ce produit"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <span className="text-[10px] text-violet-400 bg-violet-950/35 px-1.5 py-0.5 rounded-sm uppercase tracking-wider">{p.category}</span>
                          <p className="text-[11px] text-slate-400 leading-relaxed mt-1.5 line-clamp-2">{p.description}</p>
                        </div>
                        
                        <div className="border-t border-slate-900 mt-2.5 pt-2 flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-300">{p.price.toLocaleString()} FCFA</span>
                          <span className="text-[10px] text-slate-500 font-medium">Stock : {p.stock} ({p.unit})</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

        {/* TAB 2: POST A JOB */}
        {activeTab === 'recruitment' && (
          <div id="business-recruitment-tab" className="space-y-6">
            <div className="border-b border-slate-800/60 pb-4">
              <h1 className="text-xl font-bold text-white flex items-center space-x-2">
                <Briefcase className="w-5 h-5 text-violet-400" />
                <span>Publier une Offre d'Emploi de Proximité</span>
              </h1>
              <p className="text-xs text-slate-400">Publiez des opportunités d'emploi qui seront exclusivement présentées et réservées aux utilisateurs "Clients".</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              
              {/* Form poster */}
              <div className="md:col-span-5 bg-slate-950/40 border border-slate-850 p-4 rounded-2xl">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-350 mb-3.5 flex items-center space-x-1.5">
                  <FileText className="w-3.5 h-3.5 text-violet-400" />
                  <span>Nouvel Appel d'Emploi</span>
                </h3>

                <form onSubmit={handlePostJob} className="space-y-3">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Intitulé du poste *</label>
                    <input
                      id="new-job-title"
                      type="text"
                      placeholder="ex: Commis de Cuisine Adjoint"
                      value={jobTitle}
                      onChange={(e) => setJobTitle(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-violet-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Salaire proposé *</label>
                    <input
                      id="new-job-salary"
                      type="text"
                      placeholder="ex: 180,000 FCFA / mois"
                      value={jobSalary}
                      onChange={(e) => setJobSalary(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-violet-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Lieu du poste / Ville</label>
                    <input
                      id="new-job-location"
                      type="text"
                      placeholder="Dakar, Bamako, etc."
                      value={jobLocation}
                      onChange={(e) => setJobLocation(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-violet-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Ajouter des Qualifications</label>
                    <div className="flex gap-1.5">
                      <input
                        id="new-job-req-input"
                        type="text"
                        placeholder="ex: Bilingue"
                        value={jobRequirement}
                        onChange={(e) => setJobRequirement(e.target.value)}
                        className="flex-1 bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1 text-xs text-slate-100 focus:outline-none focus:border-violet-500"
                      />
                      <button
                        id="new-job-add-req-btn"
                        type="button"
                        onClick={addRequirement}
                        className="bg-violet-900 hover:bg-violet-850 text-white font-semibold px-2.5 py-1 text-xs rounded-lg"
                      >
                        +
                      </button>
                    </div>
                    {/* Temp list */}
                    <div className="flex flex-wrap gap-1 mt-2">
                      {jobReqs.map((r, i) => (
                        <span key={i} className="bg-slate-950 text-slate-350 text-[10px] px-2 py-0.5 rounded border border-slate-850 flex items-center gap-1">
                          {r}
                          <button type="button" onClick={() => setJobReqs(jobReqs.filter((_, idx) => idx !== i))} className="text-red-400 text-[9px] ml-0.5">×</button>
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Missions et descriptif *</label>
                    <textarea
                      id="new-job-desc"
                      rows={3}
                      placeholder="Quelles sont les responsabilités attachées à ce poste ?"
                      value={jobDescription}
                      onChange={(e) => setJobDescription(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 placeholder-slate-650 focus:outline-none focus:border-violet-500 resize-none"
                      required
                    />
                  </div>

                  <button
                    id="post-job-submit"
                    type="submit"
                    disabled={formLoading}
                    className="w-full py-2 bg-violet-600 hover:bg-violet-500 transition text-white font-semibold rounded-lg text-xs"
                  >
                    {formLoading ? 'Création...' : "Publier l'offre d'emploi informatique"}
                  </button>
                </form>
              </div>

              {/* My active positions posted */}
              <div className="md:col-span-7 space-y-3">
                <span className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Mes recrutements actifs ({myJobs.length})</span>
                
                {myJobs.length === 0 ? (
                  <div className="text-center py-12 text-slate-600 border border-dashed border-slate-800 rounded-2xl bg-slate-950/20">
                    Aucune offre d'emploi n'a été publiée à ce jour. Remplissez le formulaire de gauche pour démarrer vos recrutements !
                  </div>
                ) : (
                  <div className="space-y-3.5">
                    {myJobs.map((j) => (
                      <div id={`my-job-card-${j.id}`} key={j.id} className="bg-slate-950/40 border border-slate-850 rounded-xl p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-bold text-sm text-slate-200">{j.title}</h4>
                            <span className="text-[10px] text-slate-500">{j.location} • Salaire : {j.salary}</span>
                          </div>
                          <span className="text-[10px] bg-slate-900 border border-slate-800 px-2 py-0.5 rounded-full text-slate-400">
                            ID: {j.id}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 leading-relaxed mt-2.5">{j.description}</p>
                        <div className="mt-3">
                          <span className="text-[10px] text-slate-500 font-semibold block">Qualifications requises :</span>
                          <div className="flex flex-wrap gap-1.5 mt-1.5">
                            {j.requirements.map((r, idx) => (
                              <span key={idx} className="bg-slate-950 text-slate-400 border border-slate-900 text-[9px] px-2 py-0.5 rounded">
                                {r}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

        {/* TAB 3: B2B PROCUREMENT FROM SUPPLIERS */}
        {activeTab === 'b2b-procure' && (
          <div id="business-procure-tab" className="space-y-6">
            <div className="border-b border-slate-800/60 pb-4">
              <h1 className="text-xl font-bold text-white flex items-center space-x-2">
                <Tractor className="w-5 h-5 text-emerald-400" />
                <span>Approvisionnement & Relation Fournisseurs (B2B)</span>
              </h1>
              <p className="text-xs text-slate-400">Commandez vos matières premières, récoltes fraîches ou articles artisanaux directement auprès de nos producteurs et artisans locaux éleveurs.</p>
            </div>

            <div className="bg-emerald-950/10 border border-emerald-900/30 p-4 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 text-emerald-300">
              <div className="text-xs leading-relaxed">
                📢 <strong>Réseau Local de Distributeurs :</strong> Les agriculteurs, artisans et éleveurs mettent en ligne leurs productions. Les entreprises (comme vous) peuvent se fournir à prix coûtant direct-usine, sans intermédiaire.
              </div>
            </div>

            {/* List Supplier Raw Materials */}
            <div className="space-y-3">
              <span className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Matières premières disponibles d'artisans, éleveurs et agriculteurs</span>

              {supplierProducts.length === 0 ? (
                <div className="text-center py-12 text-slate-600">
                  Aucun fournisseur d'approvisionnement n'est répertorié pour l'instant.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {supplierProducts.map((p) => (
                    <div id={`supplier-item-${p.id}`} key={p.id} className="bg-slate-950/60 border border-slate-850 p-4 rounded-2xl flex flex-col justify-between hover:border-emerald-900/40 transition">
                      <div>
                        <div className="flex justify-between items-center mb-1.5">
                          <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/35 px-2 py-0.5 rounded-sm uppercase tracking-wider">
                            🚜 {p.category}
                          </span>
                          <span className="text-[10px] text-slate-500 font-medium">
                            Par • {p.sellerName}
                          </span>
                        </div>
                        <h4 className="font-bold text-sm text-slate-200">{p.title}</h4>
                        <p className="text-xs text-slate-400 mt-1">{p.description}</p>
                      </div>

                      <div className="border-t border-slate-900 mt-4 pt-3 flex items-center justify-between">
                        <div>
                          <span className="text-xs font-bold text-slate-350">{p.price.toLocaleString()} FCFA</span>
                          <span className="text-[10px] text-slate-500 block">par {p.unit} • Stock: {p.stock}</span>
                        </div>

                        {p.stock === 0 ? (
                          <span className="text-xs text-slate-600 bg-slate-950 px-2 py-1 rounded-md">Stock épuisé</span>
                        ) : (
                          <button
                            id={`procure-btn-${p.id}`}
                            onClick={() => handleProcureRawMaterials(p.id, 1)}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-3 py-1.5 rounded-xl shadow-md transition"
                          >
                            Commander 1 unité
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 4: SALES MANAGEMENT (CLIENTS ORDERS RECEIVED) */}
        {activeTab === 'sales' && (
          <div id="business-sales-tab" className="space-y-6">
            <div className="border-b border-slate-800/60 pb-4">
              <h1 className="text-xl font-bold text-white flex items-center space-x-2">
                <ShoppingCart className="w-5 h-5 text-violet-400" />
                <span>Commandes Reçues (Achats Clients)</span>
              </h1>
              <p className="text-xs text-slate-400">Gérez les achats passés par vos clients. Expédiez les marchandises et validez les livraisons de quartier.</p>
            </div>

            {myIncomingOrders.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                Vous n'avez reçu aucune commande client pour le moment.
              </div>
            ) : (
              <div className="space-y-3.5">
                {myIncomingOrders.map((o) => (
                  <div id={`incoming-order-${o.id}`} key={o.id} className="bg-slate-950/50 border border-slate-850 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center space-x-2 text-[10px] mb-1">
                        <span className="text-slate-500 font-mono font-bold">COMMANDE ID: {o.id}</span>
                        <span className="text-slate-600">•</span>
                        <span className="text-violet-350 font-semibold uppercase">Client : {o.buyerName}</span>
                      </div>
                      <h4 className="font-bold text-slate-200 text-md">{o.productTitle}</h4>
                      <p className="text-xs text-slate-400">Quantité Commandée : <strong className="text-slate-200">{o.quantity}</strong> • Montant : <strong className="text-violet-400">{(o.price * o.quantity).toLocaleString()} FCFA</strong></p>
                    </div>

                    <div className="flex flex-col sm:items-end gap-2 shrink-0">
                      <span className="text-[10px] text-slate-500">Reçu le : {new Date(o.createdAt).toLocaleDateString()}</span>
                      
                      <div className="flex items-center gap-1.5">
                        {o.status === 'pending' && (
                          <>
                            <button
                              id={`accept-order-${o.id}`}
                              onClick={() => handleOrderStatusUpdate(o.id, 'accepted')}
                              className="bg-violet-900 hover:bg-violet-850 px-3 py-1.5 text-xs text-white rounded-lg font-medium transition"
                            >
                              Accepter
                            </button>
                            <span className="bg-amber-955/30 text-amber-400 border border-amber-900/50 px-2 py-1 rounded text-[9px] font-bold uppercase">⏳ En attente</span>
                          </>
                        )}
                        {o.status === 'accepted' && (
                          <>
                            <button
                              id={`ship-order-${o.id}`}
                              onClick={() => handleOrderStatusUpdate(o.id, 'shipped')}
                              className="bg-indigo-600 hover:bg-indigo-500 px-3 py-1.5 text-xs text-white rounded-lg font-medium transition"
                            >
                              Expédier 🚚
                            </button>
                            <span className="bg-indigo-950 text-indigo-300 border border-indigo-900 px-2 py-1 rounded text-[9px] font-bold uppercase">✓ Confirmé</span>
                          </>
                        )}
                        {o.status === 'shipped' && (
                          <>
                            <button
                              id={`deliver-order-${o.id}`}
                              onClick={() => handleOrderStatusUpdate(o.id, 'delivered')}
                              className="bg-emerald-600 hover:bg-emerald-500 px-3 py-1.5 text-xs text-white rounded-lg font-medium transition"
                            >
                              Livré ✓
                            </button>
                            <span className="bg-blue-950 text-blue-300 border border-blue-900 px-2 py-1 rounded text-[9px] font-bold uppercase">🚚 En cours d'acheminement</span>
                          </>
                        )}
                        {o.status === 'delivered' && (
                          <span className="bg-emerald-950 text-emerald-300 border border-emerald-900 px-3 py-1.5 rounded-lg text-xs font-bold uppercase flex items-center gap-1">
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Reçu par le client
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 5: POINT OF SALE CASHIER & AI PREDICTIVE HUD */}
        {activeTab === 'pos' && (
          <div id="business-pos-tab" className="space-y-6">
            <div className="border-b border-slate-800/60 pb-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h1 className="text-xl font-bold text-white flex items-center space-x-2">
                    <Sparkles className="w-5 h-5 text-indigo-400" />
                    <span>Caisse Enregistreuse & Système Prédictif IA</span>
                  </h1>
                  <p className="text-xs text-slate-400">Guichet de vente physique au comptoir. L'intelligence prédictive analyse l'âge et le sexe du client pour suggérer des achats complémentaires.</p>
                </div>
                
                {/* Micro KPIs for Direct Sales */}
                <div className="flex gap-3 bg-slate-950 p-2.5 rounded-xl border border-slate-850">
                  <div className="px-2.5">
                    <span className="block text-[9px] text-slate-500 uppercase font-bold tracking-wider">Chiffre d'Affaires</span>
                    <span className="text-xs font-bold text-indigo-400">
                      {ventes.filter(v => v.entreprise_id === user.id).reduce((sum, v) => sum + v.total, 0).toLocaleString()} FCFA
                    </span>
                  </div>
                  <div className="border-l border-slate-850 pl-3 pr-2">
                    <span className="block text-[9px] text-slate-500 uppercase font-bold tracking-wider font-sans">Panier Moyen Comptoir</span>
                    <span className="text-xs font-bold text-teal-400 text-right">
                      {(() => {
                        const direct = ventes.filter(v => v.entreprise_id === user.id);
                        return direct.length ? Math.round(direct.reduce((sum, v) => sum + v.total, 0) / direct.length).toLocaleString() : 0;
                      })()} FCFA
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {posSuccess && (
              <div className="p-4 rounded-xl bg-emerald-950/35 border border-emerald-800 text-emerald-300 text-xs flex items-center space-x-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{posSuccess}</span>
              </div>
            )}

            {/* Custom Low-Stock Error Simulation (scénario vente-impossible de l'utilisateur) */}
            {posError && (
              <div className="p-4 rounded-2xl bg-red-950/30 border border-red-800/55 text-red-300 space-y-3">
                <div className="flex items-start space-x-2.5">
                  <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-sm text-red-200">⚠️ Vente Bloquée - Stocks Physiques Épuisés</h4>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Votre caisse n'a pas pu valider cette transaction car le produit <strong className="text-slate-200">"{posError.produit}"</strong> est en rupture de stock par rapport à la demande.
                    </p>
                  </div>
                </div>
                
                <div className="bg-slate-950/80 p-3 rounded-xl border border-red-900/10 text-xs flex items-center justify-between">
                  <div>
                    <span className="block text-[10px] text-slate-500 uppercase font-bold">Produit</span>
                    <span className="font-semibold text-slate-200">{posError.produit}</span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-500 uppercase font-bold text-center">Demande Guichet</span>
                    <span className="font-semibold text-red-400 text-center block">{posError.demande} unité(s)</span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-500 uppercase font-bold text-center">Disponible</span>
                    <span className="font-semibold text-teal-400 text-center block">{posError.dispo} unité(s)</span>
                  </div>
                </div>

                <div className="flex items-center space-x-3.5 pt-1">
                  <button
                    onClick={() => {
                      setActiveTab('b2b-procure');
                      setPosError(null);
                    }}
                    className="bg-emerald-600 hover:bg-emerald-500 hover:scale-101 transition duration-200 text-white text-xs font-semibold px-4 py-2 rounded-xl shadow-lg flex items-center space-x-1"
                  >
                    <span>🚜 S'approvisionner auprès des Fournisseurs (B2B)</span>
                  </button>
                  <button
                    onClick={() => setPosError(null)}
                    className="text-slate-400 hover:text-slate-200 text-xs font-medium"
                  >
                    Fermer l'alerte
                  </button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">

              {/* Col Left: POS Cash Register Controls */}
              <div className="md:col-span-8 space-y-6">
                
                {/* Subpart: Walk-in Shopper Profiles */}
                <div className="bg-slate-950/40 border border-slate-850 p-4 rounded-3xl relative overflow-hidden">
                  <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3 flex items-center space-x-2">
                    <User className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Étape 1 : Profil démographique du client au comptoir</span>
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-1.5">Tranche d'âge</label>
                      <div className="grid grid-cols-4 gap-1">
                        {["18-25", "26-39", "40-55", "55+"].map((ageOpt) => (
                          <button
                            key={ageOpt}
                            type="button"
                            onClick={() => { setPosAge(ageOpt); setPosSuccess(''); }}
                            className={`py-2 text-xs font-semibold rounded-xl text-center border transition ${posAge === ageOpt ? 'bg-indigo-600 text-white border-indigo-500 shadow-md' : 'bg-slate-950 text-slate-400 border-slate-850 hover:bg-slate-900'}`}
                          >
                            {ageOpt} ans
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-1.5">Genre / Sexe</label>
                      <div className="grid grid-cols-2 gap-1">
                        {["Femme", "Homme"].map((sexeOpt) => (
                          <button
                            key={sexeOpt}
                            type="button"
                            onClick={() => { setPosSexe(sexeOpt); setPosSuccess(''); }}
                            className={`py-2 text-xs font-semibold rounded-xl text-center border transition ${posSexe === sexeOpt ? 'bg-indigo-600 text-white border-indigo-500 shadow-md' : 'bg-slate-950 text-slate-400 border-slate-850 hover:bg-slate-900'}`}
                          >
                            {sexeOpt === "Homme" ? "Homme 🧔" : "Femme 👩"}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Subpart: Catalog Cashier Picker */}
                <div className="bg-slate-950/40 border border-slate-850 p-5 rounded-3xl">
                  <span className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Sélectionnez les articles vendus</span>
                  {myProducts.length === 0 ? (
                    <div className="text-center py-6 text-slate-600 text-xs">
                      Aucun produit en stock actuellement. <button className="underline text-indigo-400" onClick={() => setActiveTab('inventory')}>Ajouter des produits</button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {myProducts.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => handleAddPosCartItem(p)}
                          className={`p-3 text-left rounded-2xl border bg-slate-950 border-slate-850/80 hover:border-indigo-500/55 transition flex items-center justify-between group ${p.stock === 0 ? 'opacity-40 cursor-not-allowed text-slate-600' : ''}`}
                          disabled={p.stock === 0}
                        >
                          <div>
                            <span className="text-[10px] text-indigo-300 font-bold block truncate">{p.title}</span>
                            <span className="text-[9px] text-slate-500 font-mono block">Stock : {p.stock} ({p.unit})</span>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="block text-[11px] font-bold text-slate-200">{p.price.toLocaleString()} F</span>
                            <span className="text-[8px] px-1 bg-slate-900 border border-slate-800 text-slate-400 uppercase tracking-widest rounded text-center group-hover:text-indigo-300 transition">+ Ajouter</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Subpart: Receipt Ledger list */}
                <div className="bg-slate-950/30 border border-slate-850/60 p-5 rounded-3xl">
                  <span className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-3">Historique des ventes de caisse au comptoir ({ventes.filter(v => v.entreprise_id === user.id).length})</span>
                  
                  {ventes.filter(v => v.entreprise_id === user.id).length === 0 ? (
                    <div className="text-center py-8 text-slate-600 text-xs">
                      Aucun ticket de caisse enregistré.
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-[190px] overflow-y-auto pr-1">
                      {ventes.filter(v => v.entreprise_id === user.id).map((v) => (
                        <div key={v.id} className="bg-slate-950 p-2.5 rounded-xl border border-slate-855 flex justify-between items-center text-xs">
                          <div>
                            <div className="flex items-center space-x-1.5">
                              <span className="font-semibold text-slate-300">Ticket #{v.id.substring(6)}</span>
                              <span className="text-slate-600">•</span>
                              <span className="text-[10px] text-slate-400">{v.sexe === 'Homme' ? '🧔' : '👩'} ({v.age} ans)</span>
                            </div>
                            <span className="text-[9px] text-slate-500 font-mono block">{new Date(v.date_vente).toLocaleTimeString()} • {v.items.map(item => `${item.produit} (x${item.quantite})`).join(', ')}</span>
                          </div>
                          <span className="font-bold text-indigo-400 text-xs shrink-0">{v.total.toLocaleString()} FCFA</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </div>

              {/* Col Right: POS Shopping Basket & AI Suggestion Panel */}
              <div className="md:col-span-4 space-y-6">
                
                {/* Part A: POS Running Basket */}
                <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-xl relative overflow-hidden font-sans">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl"></div>
                  
                  <span className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center space-x-1.5">
                    <ShoppingCart className="w-3.5 h-3.5 text-violet-400" />
                    <span>Panier Actuel</span>
                  </span>

                  {posCart.length === 0 ? (
                    <div className="text-center py-12 text-slate-600 text-xs border border-dashed border-slate-850 rounded-2xl bg-slate-950/20">
                      Le panier est vide. Cliquez sur des produits pour les facturer.
                    </div>
                  ) : (
                    <form onSubmit={handleCheckoutPosCart} className="space-y-4">
                      <div className="space-y-2 max-h-[180px] overflow-y-auto pr-1">
                        {posCart.map((item, index) => (
                          <div key={index} className="bg-slate-950 p-2.5 rounded-xl border border-slate-850 flex items-center justify-between">
                            <div className="min-w-0 pr-1 select-none">
                              <span className="font-bold text-xs text-slate-200 block truncate">{item.produit}</span>
                              <span className="text-[10px] text-slate-500 block">{item.prix_unitaire.toLocaleString()} F / unité</span>
                            </div>
                            <div className="flex items-center space-x-2 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleRemovePosCartItem(item.produit)}
                                className="p-1 bg-slate-900 rounded-md hover:text-white hover:bg-slate-800 transition text-slate-400"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="text-xs font-bold font-mono text-slate-200">{item.quantite}</span>
                              <button
                                type="button"
                                onClick={() => {
                                  const orig = products.find(p => p.sellerId === user.id && p.title.toLowerCase() === item.produit.toLowerCase());
                                  if (orig) handleAddPosCartItem(orig);
                                }}
                                className="p-1 bg-slate-900 rounded-md hover:text-white hover:bg-slate-800 transition text-slate-400"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="border-t border-slate-800 pt-3 flex justify-between items-center text-xs">
                        <span className="text-slate-400 uppercase font-semibold text-[10px]">Total à encaisser</span>
                        <span className="text-md font-extrabold text-indigo-400">
                          {posCart.reduce((sum, item) => sum + (item.prix_unitaire * item.quantite), 0).toLocaleString()} FCFA
                        </span>
                      </div>

                      <button
                        id="pos-submit-checkout-btn"
                        type="submit"
                        disabled={posSubmitting}
                        className="w-full bg-linear-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white py-2.5 rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/10 transition duration-200 flex items-center justify-center space-x-1 text-center"
                      >
                        <span>Enregistrer l'Encaissement</span>
                      </button>
                    </form>
                  )}
                </div>

                {/* Part B: REAL-TIME AI RECOMMENDER HUD PANEL (Based on their Python algorithm) */}
                <div className="bg-slate-950 border border-indigo-900/30 p-5 rounded-3xl relative overflow-hidden font-sans">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-600/10 rounded-full blur-2xl"></div>
                  
                  <div className="flex items-center justify-between mb-3">
                    <span className="block text-[11px] font-bold text-indigo-300 uppercase tracking-widest flex items-center space-x-1">
                      <Sparkles className="w-3.5 h-3.5 text-violet-400" />
                      <span>Copilote IA Prédictif</span>
                    </span>
                    <span className="text-[9px] bg-indigo-950 text-indigo-400 border border-indigo-900/50 px-1.5 py-0.5 rounded font-bold uppercase">LIVE ML</span>
                  </div>

                  {aiInsights?.predictionResult && (
                    <div className="space-y-4">
                      
                      {/* Sub-HUD: Predicive Department Match (Logistic Regression emulation) */}
                      <div className="bg-slate-900/80 p-3.5 rounded-2xl border border-indigo-950">
                        <span className="text-[10px] text-slate-505 uppercase font-bold tracking-wider block mb-1">Affinité Prédictive de Rayon</span>
                        <div className="flex justify-between items-center">
                          <span className="font-extrabold text-sm text-slate-100">{aiInsights.predictionResult.bestRayon}</span>
                          <span className="text-[9px] font-bold bg-violet-950/70 text-violet-300 border border-violet-900/40 px-2 py-0.5 rounded-full uppercase shrink-0">
                            {aiInsights.predictionResult.level}
                          </span>
                        </div>
                        
                        {/* Probability graph indicator */}
                        <div className="mt-2 text-xs">
                          <div className="flex justify-between text-[10px] text-slate-500 font-mono mb-1">
                            <span>Score de confiance d'achat</span>
                            <span>{Math.round(aiInsights.predictionResult.bestScore * 100) || 0}%</span>
                          </div>
                          <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                            <div
                              className="bg-linear-to-r from-violet-500 to-indigo-500 h-full rounded-full transition-all duration-300"
                              style={{ width: `${Math.round(aiInsights.predictionResult.bestScore * 100)}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>

                      {/* Sub-HUD: Demographic product suggestions */}
                      <div className="space-y-2">
                        <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider block">Suggestions de Profil Démographique</span>
                        
                        {aiInsights.staticRecommendations.length === 0 ? (
                          <span className="text-[10px] text-slate-600 block italic leading-snug">Aucun modèle similaire dans l'historique pour l'instant.</span>
                        ) : (
                          <div className="space-y-1.5">
                            {aiInsights.staticRecommendations.map((rec, idx) => {
                              const actualProd = products.find(p => p.sellerId === user.id && p.title.toLowerCase() === rec.produit.toLowerCase());
                              return (
                                <div key={idx} className="bg-slate-900 p-2 rounded-xl flex items-center justify-between text-[11px] hover:border-indigo-500/30 border border-transparent transition">
                                  <div className="min-w-0 pr-2">
                                    <span className="text-[10px] text-slate-300 font-semibold block truncate">{rec.produit}</span>
                                    <span className="text-[9px] text-slate-500 block">Indice : {rec.score.toFixed(2)}</span>
                                  </div>
                                  {actualProd && actualProd.stock > 0 && (
                                    <button
                                      type="button"
                                      onClick={() => handleAddPosCartItem(actualProd)}
                                      className="p-1 px-2 bg-indigo-900 hover:bg-indigo-850 text-white rounded text-[9px] shrink-0 uppercase tracking-widest font-bold"
                                    >
                                      + Vendre
                                    </button>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>

                      {/* Sub-HUD: Co-occurrence/Combo basket suggestions */}
                      {posCart.length > 0 && (
                        <div className="space-y-2 pt-1 border-t border-slate-900">
                          <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider block leading-normal font-sans">Suggestions d'Affinité Panier (Combos)</span>
                          
                          {aiInsights.advancedRecommendations.length === 0 ? (
                            <span className="text-[10px] text-slate-600 block italic leading-snug">Aucun combo répertorié pour ces articles dans vos ventes.</span>
                          ) : (
                            <div className="space-y-1.5">
                              {aiInsights.advancedRecommendations.map((rec, idx) => {
                                const actualProd = products.find(p => p.sellerId === user.id && p.title.toLowerCase() === rec.produit.toLowerCase());
                                return (
                                  <div key={idx} className="bg-slate-900 p-2 rounded-xl flex items-center justify-between text-[11px] hover:border-pink-500/30 border border-transparent transition">
                                    <div className="min-w-0 pr-2">
                                      <span className="text-[10px] text-slate-350 font-semibold block truncate">💡 Associer : {rec.produit}</span>
                                      <span className="text-[9px] text-slate-500 block">Combo Score : {rec.score.toFixed(2)}</span>
                                    </div>
                                    {actualProd && actualProd.stock > 0 && (
                                      <button
                                        type="button"
                                        onClick={() => handleAddPosCartItem(actualProd)}
                                        className="p-1 px-2 bg-pink-950 hover:bg-pink-900 border border-pink-900/40 text-pink-300 rounded text-[9px] shrink-0 uppercase tracking-widest font-bold"
                                      >
                                        + Combo
                                      </button>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      )}

                    </div>
                  )}
                  
                  {/* Explanatory footer about ML system */}
                  <span className="block text-[8px] text-slate-600 mt-4 leading-relaxed font-sans select-none">
                    * Modélisation basée sur le score d'affinité profile-matching (Age, Sexe) et l'analyse de corrélation par panier croisé.
                  </span>
                </div>

              </div>

            </div>

          </div>
        )}

      </div>
    </div>
  );
}
