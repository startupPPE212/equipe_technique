import React, { useState, useEffect } from 'react';
import { UserProfile, Product, JobOffer, Order, Vente } from './types';
import AuthScreen from './components/AuthScreen';
import ClientDashboard from './components/ClientDashboard';
import BusinessDashboard from './components/BusinessDashboard';
import SupplierDashboard from './components/SupplierDashboard';
import { Sparkles, Power, Users, ShoppingBag, Briefcase, RefreshCw, Layers } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  
  // Real-time Database Snapshot
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [jobOffers, setJobOffers] = useState<JobOffer[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [ventes, setVentes] = useState<Vente[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Fetch full state from backend
  const fetchState = async () => {
    setRefreshing(true);
    try {
      const response = await fetch('/api/state');
      if (response.ok) {
        const data = await response.json();
        setUsers(data.users || []);
        setProducts(data.products || []);
        setJobOffers(data.jobOffers || []);
        setOrders(data.orders || []);
        setVentes(data.ventes || []);
      }
    } catch (err) {
      console.error("Erreur d'acquisition de l'état:", err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchState();
  }, []);

  // Update current user references when refreshing lists in case it has updated info
  useEffect(() => {
    if (currentUser) {
      const matched = users.find(u => u.id === currentUser.id);
      if (matched) {
        setCurrentUser(matched);
      }
    }
  }, [users]);

  const handleLogout = () => {
    setCurrentUser(null);
  };

  if (loading) {
    return (
      <div id="app-loading-container" className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-150 py-12">
        <div className="flex items-center space-x-3 mb-6 animate-pulse">
          <div className="p-3 bg-indigo-600 rounded-2xl text-white shadow-lg">
            <Sparkles className="h-6 w-6" />
          </div>
          <h2 className="text-xl font-bold text-white tracking-wide">StartupConnect</h2>
        </div>
        <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 shadow-md">
          <RefreshCw className="w-4 h-4 text-indigo-400 animate-spin" />
          <span className="text-xs text-slate-400">Synchronisation de notre écosystème de quartier...</span>
        </div>
      </div>
    );
  }

  // Not logged in -> Show Auth board with login or signup capabilities
  if (!currentUser) {
    return (
      <AuthScreen
        onLoginSuccess={(user) => setCurrentUser(user)}
        availableUsers={users}
        onRefreshState={fetchState}
      />
    );
  }

  // Count active stats for informational cards
  const activeBusinessesCount = users.filter(u => u.profileType === 'entreprise').length;
  const activeSuppliersCount = users.filter(u => u.profileType === 'fournisseur').length;
  const clientViewProducts = products.filter(p => p.sellerType === 'entreprise');

  return (
    <div id="app-workspace-main" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between font-sans selection:bg-indigo-600 selection:text-white pb-12">
      
      {/* Dynamic Header Navbar Bar */}
      <header id="app-global-header" className="sticky top-0 z-50 bg-slate-900/90 border-b border-slate-800/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
          
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-indigo-600 rounded-xl text-white shadow-md shadow-indigo-600/20">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <span className="font-extrabold tracking-tight text-white block text-md">StartupConnect</span>
              <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest block -mt-1">Relier l'Économie locale</span>
            </div>
          </div>

          {/* Quick ecosystem counter labels */}
          <div className="hidden md:flex items-center space-x-4">
            <div className="bg-slate-950 border border-slate-850 px-3 py-1.5 rounded-xl text-xs flex items-center space-x-2 text-slate-400">
              <Users className="w-3.5 h-3.5 text-indigo-400" />
              <span><strong>{activeBusinessesCount}</strong> Commerces</span>
            </div>
            <div className="bg-slate-950 border border-slate-850 px-3 py-1.5 rounded-xl text-xs flex items-center space-x-2 text-slate-400">
              <Layers className="w-3.5 h-3.5 text-emerald-400" />
              <span><strong>{activeSuppliersCount}</strong> Producteurs</span>
            </div>
            <div className="bg-slate-950 border border-slate-850 px-3 py-1.5 rounded-xl text-xs flex items-center space-x-2 text-slate-400">
              <Briefcase className="w-3.5 h-3.5 text-amber-400" />
              <span><strong>{jobOffers.length}</strong> Métiers</span>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {/* Realtime Synchronizer */}
            <button
              id="global-sync-btn"
              onClick={fetchState}
              disabled={refreshing}
              className="p-1 px-2.5 bg-slate-950 hover:bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-400 hover:text-white transition flex items-center space-x-1.5 disabled:opacity-50"
              title="Rafraîchir les données"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-indigo-400' : ''}`} />
              <span className="hidden sm:inline">Sync en direct</span>
            </button>

            {/* Profile pill */}
            <div className="flex items-center space-x-2.5 bg-slate-950 border border-slate-800/80 rounded-xl p-1.5 pr-3.5">
              <img
                src={currentUser.avatarUrl || `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(currentUser.name)}`}
                alt="avatar"
                className="w-7 h-7 rounded-lg bg-slate-900"
              />
              <div className="text-left">
                <span className="text-xs font-semibold text-slate-100 block truncate max-w-[120px]">{currentUser.name}</span>
                <span className="text-[10px] text-indigo-400 block -mt-0.5 capitalize">{currentUser.profileType}</span>
              </div>
            </div>

            {/* Logout button */}
            <button
              id="global-logout-btn"
              onClick={handleLogout}
              className="p-2.5 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 text-red-400 hover:text-red-300 rounded-xl transition"
              title="Déconnexion"
            >
              <Power className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace Frame */}
      <main id="app-workspace-frame" className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Render Profile Specific Dashboard */}
        {currentUser.profileType === 'client' && (
          <ClientDashboard
            user={currentUser}
            products={products}
            jobOffers={jobOffers}
            orders={orders}
            onRefreshState={fetchState}
          />
        )}

        {currentUser.profileType === 'entreprise' && (
          <BusinessDashboard
            user={currentUser}
            products={products}
            jobOffers={jobOffers}
            orders={orders}
            ventes={ventes}
            onRefreshState={fetchState}
          />
        )}

        {currentUser.profileType === 'fournisseur' && (
          <SupplierDashboard
            user={currentUser}
            products={products}
            orders={orders}
            onRefreshState={fetchState}
            allBusinesses={users.filter(u => u.profileType === 'entreprise')}
          />
        )}

      </main>

    </div>
  );
}
