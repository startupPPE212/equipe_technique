/**
 * Types & Interfaces for the Multi-Profile B2B2C Marketplace
 */

export type ProfileType = 'client' | 'entreprise' | 'fournisseur';

export type EnterpriseType = 
  | 'supermarche' 
  | 'marche' 
  | 'alimentation' 
  | 'restaurant' 
  | 'secretariat' 
  | 'hotel'
  | 'autre';

export type SupplierType = 
  | 'agriculteur' 
  | 'artisan' 
  | 'eleveur' 
  | 'autre';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  profileType: ProfileType;
  // Dynamic fields based on profile type
  enterpriseType?: EnterpriseType;
  supplierType?: SupplierType;
  description?: string;
  address?: string;
  phone?: string;
  avatarUrl?: string;
}

export interface Product {
  id: string;
  sellerId: string; // User ID (Enterprise or Supplier)
  sellerName: string;
  sellerType: ProfileType; // 'entreprise' (selling to client) or 'fournisseur' (selling to enterprise)
  title: string;
  description: string;
  price: number;
  category: string;
  imageUrl?: string;
  stock: number;
  unit: string; // e.g. "kg", "unité", "litres"
}

export interface JobOffer {
  id: string;
  companyId: string;
  companyName: string;
  companyType: EnterpriseType;
  title: string;
  description: string;
  salary: string;
  location: string;
  requirements: string[];
  createdAt: string;
}

export interface Order {
  id: string;
  buyerId: string;
  buyerName: string;
  sellerId: string;
  sellerName: string;
  productId: string;
  productTitle: string;
  price: number;
  quantity: number;
  status: 'pending' | 'accepted' | 'shipped' | 'delivered';
  createdAt: string;
}

export interface VenteItem {
  id: string;
  rayon: string;
  produit: string;
  quantite: number;
  prix_unitaire: number;
  total: number;
}

export interface Vente {
  id: string;
  entreprise_id: string;
  age: string; // e.g. "18-25", "26-39", "40-55", "55+"
  sexe: string; // e.g. "Homme", "Femme"
  total: number;
  date_vente: string;
  items: VenteItem[];
}

export interface PredictionResult {
  bestRayon: string;
  bestScore: number;
  level: 'TRÈS FIABLE 🔥' | 'MOYENNEMENT FIABLE ⚠️' | 'DONNÉES INSUFFISANTES ⚠️';
  probabilities: { rayon: string; proba: number }[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}
